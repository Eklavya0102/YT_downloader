"""Temporary-file cleanup: per-job removal, orphan purge, and a background sweeper."""
from __future__ import annotations

import logging
import shutil
import threading
import time
from pathlib import Path

log = logging.getLogger("streamdrop.cleanup")


def remove_job_dir(path: str | None, temp_root: str) -> None:
    """Delete a job directory, but only if it really lives inside the temp root."""
    if not path:
        return
    try:
        target = Path(path).resolve()
        root = Path(temp_root).resolve()
        if root in target.parents:
            shutil.rmtree(target, ignore_errors=True)
        else:
            log.warning("refusing to delete directory outside temp root")
    except OSError:
        log.exception("failed to remove job directory")


def purge_orphans(temp_root: str, keep: set[str], min_age_seconds: int) -> int:
    """Remove directories in temp_root that no live job owns. Returns the number removed."""
    root = Path(temp_root)
    removed = 0
    if not root.is_dir():
        return 0
    now = time.time()
    for child in root.iterdir():
        try:
            if not child.is_dir() or str(child.resolve()) in keep:
                continue
            if now - child.stat().st_mtime >= min_age_seconds:
                shutil.rmtree(child, ignore_errors=True)
                removed += 1
        except OSError:
            continue
    return removed


class CleanupThread(threading.Thread):
    """Periodically expires finished jobs and purges orphaned directories."""

    def __init__(self, queue, interval_seconds: int):
        super().__init__(name="streamdrop-cleanup", daemon=True)
        self._queue = queue
        self._interval = interval_seconds
        self._stop_event = threading.Event()

    def run(self) -> None:
        while not self._stop_event.wait(self._interval):
            try:
                self._queue.sweep()
            except Exception:  # keep the sweeper alive no matter what
                log.exception("cleanup sweep failed")

    def stop(self) -> None:
        self._stop_event.set()
