"""Small in-process sliding-window rate limiter (per worker process; fine for one instance)."""
from __future__ import annotations

import threading
import time
from collections import deque
from typing import Deque, Dict, Tuple


class SlidingWindowLimiter:
    def __init__(self, limit: int, window_seconds: int):
        self.limit = limit
        self.window = window_seconds
        self._hits: Dict[str, Deque[float]] = {}
        self._lock = threading.Lock()
        self._last_prune = time.monotonic()

    def hit(self, key: str) -> Tuple[bool, int]:
        """Record a request. Returns (allowed, retry_after_seconds)."""
        now = time.monotonic()
        with self._lock:
            if now - self._last_prune > self.window:
                self._prune(now)
            hits = self._hits.setdefault(key, deque())
            while hits and now - hits[0] >= self.window:
                hits.popleft()
            if len(hits) >= self.limit:
                return False, max(1, int(self.window - (now - hits[0])) + 1)
            hits.append(now)
            return True, 0

    def _prune(self, now: float) -> None:
        for key in [k for k, v in self._hits.items() if not v or now - v[-1] >= self.window]:
            del self._hits[key]
        self._last_prune = now
