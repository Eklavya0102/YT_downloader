import os
import sys
import time
from pathlib import Path

os.environ["STREAMDROP_SKIP_DEFAULT_APP"] = "1"
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import pytest

from app import create_app
from config import Config
from downloader import MediaError
from queue_manager import InMemoryJobQueue

VIDEO_ID = "dQw4w9WgXcQ"
URL = f"https://www.youtube.com/watch?v={VIDEO_ID}"
FRONTEND = "https://streamdrop.example.com"


def fake_metadata(url, config, platform="youtube"):
    return {
        "platform": "youtube", "platform_label": "YouTube", "quality_mode": "selectable",
        "watermark_free": {"applies": False, "available": False, "qualities": [], "reason": None},
        "notes": [],
        "video_id": VIDEO_ID, "title": "Test Video", "thumbnail": "https://i.ytimg.com/vi/x/hq.jpg",
        "duration": 120, "duration_text": "2:00", "uploader": "Tester", "max_height": 720, "resolutions": [360, 720],
        "formats": {
            "mp4": {"available": True, "qualities": ["360p", "720p", "best"], "reason": None},
            "mp3": {"available": True, "bitrates": [128, 192, 256, 320], "reason": None},
        },
    }


def make_config(tmp_path, **overrides):
    base = dict(app_env="production", allowed_origins=(FRONTEND,), temp_dir=str(tmp_path / "work"),
                rate_metadata=(1000, 60), rate_downloads=(1000, 60), rate_status=(1000, 60),
                max_jobs_per_client=10, cleanup_interval_seconds=3600)
    base.update(overrides)
    return Config(**base)


def fake_runner_factory(delay=0.0, fail_with=None, gate=None):
    def runner(job, report):
        if gate is not None:
            gate.wait(timeout=5)
        report("downloading", percent=50.0, downloaded_bytes=5, total_bytes=10, indeterminate=False)
        if delay:
            time.sleep(delay)
        if fail_with:
            raise fail_with
        ext = "mp3" if job.request.fmt == "mp3" else "mp4"
        path = Path(job.work_dir) / f"media.{ext}"
        path.write_bytes(b"fake-media-bytes")
        return {"path": str(path), "filename": f"Test Video.{ext}", "size": path.stat().st_size,
                "mimetype": "audio/mpeg" if ext == "mp3" else "video/mp4"}
    return runner


@pytest.fixture
def make_app(tmp_path, monkeypatch):
    monkeypatch.setattr("app.ffmpeg_available", lambda config=None: True)
    created = []

    def _make(runner=None, fetcher=fake_metadata, link_resolver=None, **cfg):
        config = make_config(tmp_path, **cfg)
        queue = InMemoryJobQueue(config, runner or fake_runner_factory())
        app = create_app(config, queue=queue, metadata_fetcher=fetcher, link_resolver=link_resolver, start_workers=False)
        created.append(queue)
        return app, queue, config

    yield _make
    for q in created:
        q.shutdown()


def wait_for(predicate, timeout=5.0):
    end = time.time() + timeout
    while time.time() < end:
        if predicate():
            return True
        time.sleep(0.02)
    return False
