from conftest import FRONTEND


def preflight(client, origin, path="/api/metadata"):
    return client.options(path, headers={"Origin": origin, "Access-Control-Request-Method": "POST",
                                         "Access-Control-Request-Headers": "content-type"})


def test_allowed_origin_gets_cors_headers(make_app):
    app, _, _ = make_app()
    r = app.test_client().get("/api/health", headers={"Origin": FRONTEND})
    assert r.headers["Access-Control-Allow-Origin"] == FRONTEND
    assert "Content-Disposition" in r.headers.get("Access-Control-Expose-Headers", "")
    assert preflight(app.test_client(), FRONTEND).headers["Access-Control-Allow-Origin"] == FRONTEND


def test_unknown_origin_is_not_allowed(make_app):
    app, _, _ = make_app()
    r = app.test_client().get("/api/health", headers={"Origin": "https://evil.example"})
    assert "Access-Control-Allow-Origin" not in r.headers
    assert "Access-Control-Allow-Origin" not in preflight(app.test_client(), "https://evil.example").headers


def test_wildcard_is_never_used(make_app):
    app, _, _ = make_app()
    r = app.test_client().get("/api/health", headers={"Origin": FRONTEND})
    assert r.headers["Access-Control-Allow-Origin"] != "*"


def test_preview_regex_is_anchored(make_app):
    app, _, _ = make_app(allowed_origin_regex=r"https://streamdrop-[a-z0-9-]+-team\.vercel\.app")
    c = app.test_client()
    good = "https://streamdrop-git-feature-team.vercel.app"
    assert c.get("/api/health", headers={"Origin": good}).headers["Access-Control-Allow-Origin"] == good
    evil = good + ".evil.com"
    assert "Access-Control-Allow-Origin" not in c.get("/api/health", headers={"Origin": evil}).headers


def test_no_configured_origins_means_no_cors(make_app):
    app, _, _ = make_app(allowed_origins=())
    r = app.test_client().get("/api/health", headers={"Origin": FRONTEND})
    assert "Access-Control-Allow-Origin" not in r.headers


def test_wildcard_env_value_is_dropped():
    from config import _origins
    assert _origins("*, https://a.com/ ,") == ("https://a.com",)
