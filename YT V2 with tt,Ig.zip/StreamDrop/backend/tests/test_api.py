import threading

from conftest import FRONTEND, URL, VIDEO_ID, fake_metadata, fake_runner_factory, wait_for
from downloader import MediaError, build_metadata, translate_error
from config import Config


def post(client, path, body, **kw):
    return client.post(path, json=body, **kw)


def test_health_and_capabilities(make_app):
    app, _, _ = make_app()
    c = app.test_client()
    r = c.get("/api/health")
    assert r.status_code == 200 and r.json["status"] == "ok" and r.json["version"]
    caps = c.get("/api/capabilities").json
    assert caps["formats"]["mp4"]["qualities"][-1] == "best"
    assert caps["queue"]["max_waiting"] == 5 and caps["queue"]["durable"] is False


def test_metadata_ok_and_invalid(make_app):
    app, _, _ = make_app()
    c = app.test_client()
    r = post(c, "/api/metadata", {"url": URL})
    assert r.status_code == 200 and r.json["metadata"]["title"] == "Test Video"
    for bad in ({"url": "http://127.0.0.1/x"}, {"url": "https://evil.com"}, {}, {"url": 5}):
        r = post(c, "/api/metadata", bad)
        assert r.status_code == 400 and r.json["ok"] is False and "code" in r.json["error"]
    assert c.post("/api/metadata", data="not json", content_type="text/plain").status_code == 400


def test_metadata_errors_are_controlled(make_app):
    def boom(url, cfg, platform="youtube"):
        raise MediaError("video_private", "This video is private.", 422)
    app, _, _ = make_app(fetcher=boom)
    r = post(app.test_client(), "/api/metadata", {"url": URL})
    assert r.status_code == 422 and r.json["error"]["code"] == "video_private"

    def crash(url, cfg, platform="youtube"):
        raise RuntimeError("secret /srv/path leak?")
    app, _, _ = make_app(fetcher=crash)
    r = post(app.test_client(), "/api/metadata", {"url": URL})
    assert r.status_code == 500 and "secret" not in r.get_data(as_text=True)


def test_create_download_validation(make_app):
    app, _, _ = make_app()
    c = app.test_client()
    assert post(c, "/api/downloads", {"url": URL, "format": "avi"}).json["error"]["code"] == "invalid_format"
    assert post(c, "/api/downloads", {"url": URL, "format": "mp4", "quality": "999p"}).json["error"]["code"] == "invalid_quality"
    r = post(c, "/api/downloads", {"url": URL, "format": "mp4", "quality": "1080p"})  # valid choice, not offered by source
    assert r.status_code == 422 and r.json["error"]["code"] == "quality_unavailable"
    assert post(c, "/api/downloads", {"url": "http://localhost/", "format": "mp4"}).status_code == 400


def test_job_lifecycle_and_file_delivery(make_app):
    gate = threading.Event()
    app, queue, _ = make_app(runner=fake_runner_factory(gate=gate))
    queue.start()
    c = app.test_client()
    r = post(c, "/api/downloads", {"url": URL, "format": "mp4", "quality": "720p"})
    assert r.status_code == 202
    job_id = r.json["job"]["id"]
    assert len(job_id) >= 20 and "path" not in str(r.json).lower()
    assert c.get(f"/api/downloads/{job_id}/file").status_code in (409,)  # not ready yet
    assert wait_for(lambda: c.get(f"/api/downloads/{job_id}").json["job"]["status"] == "processing")
    gate.set()
    assert wait_for(lambda: c.get(f"/api/downloads/{job_id}").json["job"]["status"] == "completed")
    job = c.get(f"/api/downloads/{job_id}").json["job"]
    assert job["filename"] == "Test Video.mp4" and job["stage"] == "ready"
    f = c.get(f"/api/downloads/{job_id}/file")
    assert f.status_code == 200 and f.data == b"fake-media-bytes"
    assert "attachment" in f.headers["Content-Disposition"] and f.mimetype == "video/mp4"
    assert f.headers["Content-Length"] == str(len(b"fake-media-bytes"))


def test_failed_job_reports_safe_error_and_cleans_up(make_app):
    app, queue, config = make_app(runner=fake_runner_factory(fail_with=MediaError("processing_failed", "Media conversion failed.")))
    queue.start()
    c = app.test_client()
    job_id = post(c, "/api/downloads", {"url": URL, "format": "mp3"}).json["job"]["id"]
    assert wait_for(lambda: c.get(f"/api/downloads/{job_id}").json["job"]["status"] == "failed")
    job = c.get(f"/api/downloads/{job_id}").json["job"]
    assert job["error"]["code"] == "processing_failed"
    import os
    assert wait_for(lambda: not any(os.scandir(config.temp_dir)))


def test_unknown_or_malformed_job_ids(make_app):
    app, _, _ = make_app()
    c = app.test_client()
    assert c.get("/api/downloads/doesnotexistdoesnotexist1").status_code == 404
    assert c.get("/api/downloads/..%2F..%2Fetc%2Fpasswd/file").status_code == 404
    assert c.get("/api/downloads/short/file").status_code == 404
    assert c.delete("/api/downloads/short").status_code == 404


def test_expiry_returns_410_and_removes_file(make_app):
    app, queue, config = make_app()
    queue.start()
    c = app.test_client()
    job_id = post(c, "/api/downloads", {"url": URL, "format": "mp4", "quality": "best"}).json["job"]["id"]
    assert wait_for(lambda: c.get(f"/api/downloads/{job_id}").json["job"]["status"] == "completed")
    job = queue.get(job_id)
    queue.sweep(now=job.expires_at + 1)
    assert c.get(f"/api/downloads/{job_id}").json["job"]["status"] == "expired"
    assert c.get(f"/api/downloads/{job_id}/file").status_code == 410
    import os
    assert not any(os.scandir(config.temp_dir))


def test_delivery_shortens_expiry(make_app):
    app, queue, config = make_app(delivered_grace_seconds=5)
    queue.start()
    c = app.test_client()
    job_id = post(c, "/api/downloads", {"url": URL, "format": "mp3"}).json["job"]["id"]
    assert wait_for(lambda: c.get(f"/api/downloads/{job_id}").json["job"]["status"] == "completed")
    before = queue.get(job_id).expires_at
    assert c.get(f"/api/downloads/{job_id}/file").data == b"fake-media-bytes"
    assert queue.get(job_id).expires_at < before


def test_rate_limit_returns_429_with_retry_after(make_app):
    app, _, _ = make_app(rate_metadata=(2, 60))
    c = app.test_client()
    assert post(c, "/api/metadata", {"url": URL}).status_code == 200
    assert post(c, "/api/metadata", {"url": URL}).status_code == 200
    r = post(c, "/api/metadata", {"url": URL})
    assert r.status_code == 429 and int(r.headers["Retry-After"]) >= 1


def test_unknown_route_and_method_use_json_errors(make_app):
    app, _, _ = make_app()
    c = app.test_client()
    assert c.get("/api/nope").json["error"]["code"] == "not_found"
    assert c.put("/api/health").status_code == 405


def test_security_headers_present(make_app):
    app, _, _ = make_app()
    h = app.test_client().get("/api/health").headers
    assert h["X-Content-Type-Options"] == "nosniff" and h["X-Frame-Options"] == "DENY"


def test_build_metadata_only_offers_real_resolutions():
    cfg = Config()
    info = {"id": VIDEO_ID, "title": "T", "duration": 60, "formats": [
        {"vcodec": "avc1", "height": 360, "acodec": "none"}, {"vcodec": "avc1", "height": 1080, "acodec": "none"},
        {"vcodec": "none", "acodec": "opus"}]}
    md = build_metadata(info, cfg, ffmpeg_ok=True)
    assert md["resolutions"] == [360, 1080] and md["formats"]["mp4"]["qualities"] == ["360p", "1080p", "best"]
    assert md["formats"]["mp3"]["available"] is True
    live = build_metadata({**info, "is_live": True}, cfg, ffmpeg_ok=True)
    assert live["formats"]["mp4"]["available"] is False
    assert build_metadata({**info, "duration": 10**6}, cfg, ffmpeg_ok=True)["formats"]["mp3"]["available"] is False
    assert md["thumbnail"].startswith("https://i.ytimg.com/")
    assert build_metadata({**info, "thumbnail": "http://169.254.169.254/x.jpg"}, cfg, True)["thumbnail"].startswith("https://i.ytimg.com/")


def test_translate_error_hides_internals():
    err = translate_error(Exception("ERROR: [youtube] abc: Private video. Sign in at /home/user/.cache"))
    assert err.code == "video_private" and "/home" not in err.message
    assert translate_error(Exception("weird")).code == "extraction_failed"
