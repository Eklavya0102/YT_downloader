"""TikTok / Instagram / YouTube platform support. All network access is mocked or avoided."""
import email.message
import urllib.error

import pytest
import yt_dlp

import downloader
from conftest import fake_metadata, fake_runner_factory, wait_for
from config import Config
from downloader import (MediaError, build_metadata, redact, resolve_short_url, translate_error, video_format_selector)
from validators import (ValidationError, detect_platform, parse_download_request, parse_media_url, parse_quality)

TT_ID = "6718335390845095173"
TT_URL = f"https://www.tiktok.com/@scout2015/video/{TT_ID}"
IG_URL = "https://www.instagram.com/reel/Cabc123XYZ/"
YT_URL = "https://www.youtube.com/watch?v=dQw4w9WgXcQ"


# ---------------------------------------------------------------- URL validation and detection
@pytest.mark.parametrize("url,platform,media_id,canonical", [
    (YT_URL, "youtube", "dQw4w9WgXcQ", YT_URL),
    (f"https://youtu.be/dQw4w9WgXcQ?si=x", "youtube", "dQw4w9WgXcQ", YT_URL),
    (TT_URL, "tiktok", TT_ID, TT_URL),
    (f"https://tiktok.com/@scout2015/video/{TT_ID}?is_from_webapp=1&sender_device=pc", "tiktok", TT_ID, TT_URL),
    (f"https://m.tiktok.com/@a.b_c/video/{TT_ID}", "tiktok", TT_ID, f"https://www.tiktok.com/@a.b_c/video/{TT_ID}"),
    ("https://www.instagram.com/reel/Cabc123XYZ/?igsh=abc", "instagram", "Cabc123XYZ", IG_URL),
    ("https://instagram.com/reels/Cabc123XYZ", "instagram", "Cabc123XYZ", IG_URL),
    ("https://www.instagram.com/p/Cabc123XYZ/", "instagram", "Cabc123XYZ", "https://www.instagram.com/p/Cabc123XYZ/"),
    ("https://www.instagram.com/tv/Cabc123XYZ/", "instagram", "Cabc123XYZ", "https://www.instagram.com/tv/Cabc123XYZ/"),
    ("https://www.instagram.com/some.user/reel/Cabc123XYZ/", "instagram", "Cabc123XYZ", IG_URL),
])
def test_valid_urls_are_detected_and_canonicalised(url, platform, media_id, canonical):
    ref = parse_media_url(url)
    assert (ref.platform, ref.media_id, ref.url) == (platform, media_id, canonical)
    assert detect_platform(url) == platform


@pytest.mark.parametrize("url,code", [
    (f"https://www.tiktok.com/@scout2015/photo/{TT_ID}", "unsupported_content"),
    ("https://www.tiktok.com/@scout2015", "unsupported_content"),
    ("https://www.tiktok.com/@scout2015/video/abc", "unsupported_url"),
    ("https://www.tiktok.com/@scout2015/video/123", "unsupported_url"),
    ("https://www.tiktok.com/discover", "unsupported_url"),
    (f"https://tiktok.com.evil.com/@a/video/{TT_ID}", "unsupported_host"),
    (f"https://www.tiktok.com@evil.com/@a/video/{TT_ID}", "invalid_url"),
    ("https://www.instagram.com/stories/user/123456/", "unsupported_content"),
    ("https://www.instagram.com/someuser/", "unsupported_content"),
    ("https://www.instagram.com/share/reel/BAbc123/", "unsupported_url"),
    ("https://www.instagram.com/reels/audio/12345/", "unsupported_url"),
    ("https://www.instagram.com/explore/tags/cats/", "unsupported_url"),
    ("https://instagram.com.evil.com/reel/Cabc123XYZ/", "unsupported_host"),
    ("https://www.instagram.com/reel/ab/", "unsupported_url"),
    ("https://example.com/video.mp4", "unsupported_host"),
    ("http://127.0.0.1/reel/Cabc123XYZ/", "unsupported_host"),
    ("http://169.254.169.254/latest/meta-data", "unsupported_host"),
    ("file:///etc/passwd", "invalid_url"),
    ("https://vimeo.com/123456", "unsupported_host"),
])
def test_invalid_urls_rejected_with_specific_codes(url, code):
    with pytest.raises(ValidationError) as exc:
        parse_media_url(url)
    assert exc.value.code == code and exc.value.status in (400, 422)


def test_detect_platform_unknown_and_garbage():
    assert detect_platform("https://example.com/") is None
    assert detect_platform(None) is None and detect_platform("not a url") is None


def test_disabled_platform_is_refused():
    with pytest.raises(ValidationError) as exc:
        parse_media_url(TT_URL, enabled=("youtube",))
    assert exc.value.code == "platform_disabled"
    assert parse_media_url(YT_URL, enabled=("youtube",)).platform == "youtube"


# ---------------------------------------------------------------- short link resolution
def test_tiktok_short_links_use_resolver_and_revalidate():
    seen = []
    def resolver(url):
        seen.append(url)
        return TT_URL + "?utm=x"
    for short in ("https://vm.tiktok.com/ZMabc123/", "https://vt.tiktok.com/ZSabc123", "https://www.tiktok.com/t/ZTabc123/"):
        assert parse_media_url(short, resolver).url == TT_URL
    assert seen[0] == "https://vm.tiktok.com/ZMabc123"


@pytest.mark.parametrize("target", [
    f"https://evil.example/@a/video/{TT_ID}", f"http://www.tiktok.com/@a/video/{TT_ID}",
    "https://www.tiktok.com/", "https://www.tiktok.com/t/ZTabc123/", "http://169.254.169.254/",
])
def test_short_link_target_must_be_a_tiktok_video(target):
    with pytest.raises(ValidationError):
        parse_media_url("https://vm.tiktok.com/ZMabc123/", lambda u: target)


def test_short_link_without_resolver_or_with_failure():
    with pytest.raises(ValidationError):
        parse_media_url("https://vm.tiktok.com/ZMabc123/")
    def failing(url):
        raise ValidationError("short_link_unresolvable", "nope", 422)
    with pytest.raises(ValidationError) as exc:
        parse_media_url("https://vm.tiktok.com/ZMabc123/", failing)
    assert exc.value.code == "short_link_unresolvable"


class _FakeOpener:
    def __init__(self, hops):
        self.hops = list(hops)
    def open(self, request, timeout=None):
        kind, value = self.hops.pop(0)
        if kind == "redirect":
            headers = email.message.Message(); headers["Location"] = value
            raise urllib.error.HTTPError(request.full_url, 302, "Found", headers, None)
        if kind == "http":
            raise urllib.error.HTTPError(request.full_url, value, "err", email.message.Message(), None)
        if kind == "net":
            raise urllib.error.URLError("down")
        class R:  # final 200
            def close(self): pass
        return R()


def test_resolver_follows_only_https_tiktok_hops(monkeypatch):
    ok = [("redirect", "https://www.tiktok.com/@a/video/123456789?x=1")]
    monkeypatch.setattr("urllib.request.build_opener", lambda *a: _FakeOpener(ok))
    assert resolve_short_url("https://vm.tiktok.com/abc").startswith("https://www.tiktok.com/@a/video/")
    for hops in ([("redirect", "https://evil.example/x")], [("redirect", "http://www.tiktok.com/x")],
                 [("http", 404)], [("net", None)], [("redirect", "https://vm.tiktok.com/b")] * 5):
        monkeypatch.setattr("urllib.request.build_opener", lambda *a, h=hops: _FakeOpener(h))
        with pytest.raises(ValidationError) as exc:
            resolve_short_url("https://vm.tiktok.com/abc")
        assert exc.value.code == "short_link_unresolvable"


# ---------------------------------------------------------------- quality / request validation
def test_quality_rules_per_platform():
    assert parse_quality("540p", "tiktok") == 540 and parse_quality("best", "instagram") == "best"
    for bad in ("50p", "9999p", "abc", "720x"):
        with pytest.raises(ValidationError):
            parse_quality(bad, "tiktok")
    with pytest.raises(ValidationError):  # YouTube stays on its fixed ladder
        parse_quality("540p", "youtube")


def test_download_request_watermark_field_validation():
    req = parse_download_request({"url": TT_URL, "format": "mp4", "quality": "best", "watermark_free": True}, 192)
    assert req.platform == "tiktok" and req.watermark_free is True
    off = parse_download_request({"url": TT_URL, "format": "mp4"}, 192)
    assert off.watermark_free is False and off.fingerprint != req.fingerprint
    for body in ({"url": TT_URL, "format": "mp4", "watermark_free": "yes"},
                 {"url": TT_URL, "format": "mp4", "watermark_free": 1},
                 {"url": TT_URL, "format": "mp3", "watermark_free": True},
                 {"url": YT_URL, "format": "mp4", "watermark_free": True}):
        with pytest.raises(ValidationError) as exc:
            parse_download_request(body, 192)
        assert exc.value.code == "invalid_watermark_free"


# ---------------------------------------------------------------- metadata shaping
def tt_formats(clean_heights=(540, 720), marked_heights=(720,)):
    fmts = [{"format_id": f"play{h}", "format_note": "Direct video", "vcodec": "h264", "acodec": "aac", "height": h,
             "ext": "mp4", "protocol": "https", "url": "u"} for h in clean_heights]
    fmts += [{"format_id": f"dl{h}", "format_note": "Download video, watermarked", "vcodec": "h264", "acodec": "aac",
              "height": h, "ext": "mp4", "protocol": "https", "url": "u"} for h in marked_heights]
    return fmts


def test_tiktok_metadata_reports_watermark_free_only_when_source_offers_it():
    cfg = Config()
    info = {"id": TT_ID, "title": "t", "duration": 15, "uploader": "scout", "formats": tt_formats(),
            "thumbnail": "https://p16-sign.tiktokcdn.com/obj/x.jpeg"}
    md = build_metadata(info, cfg, True, "tiktok")
    assert md["platform"] == "tiktok" and md["watermark_free"]["available"] is True
    assert md["formats"]["mp4"]["qualities"] == ["540p", "720p", "best"] and md["quality_mode"] == "selectable"
    assert md["thumbnail"].startswith("https://p16-sign.tiktokcdn.com/")

    only_marked = build_metadata({**info, "formats": tt_formats(clean_heights=(), marked_heights=(720,))}, cfg, True, "tiktok")
    assert only_marked["watermark_free"]["available"] is False and "watermarked" in only_marked["watermark_free"]["reason"]
    assert only_marked["formats"]["mp4"]["qualities"] == ["best"] and only_marked["quality_mode"] == "original"


def test_instagram_never_claims_watermark_free_and_shows_no_youtube_ladder():
    fmts = [{"format_id": "v", "vcodec": "h264", "acodec": "aac", "height": 1080, "url": "u"}]
    md = build_metadata({"id": "C1", "title": "r", "duration": 9, "formats": fmts, "thumbnail": "https://evil.example/t.jpg"},
                        Config(), True, "instagram")
    assert md["watermark_free"]["available"] is False and md["watermark_free"]["applies"] is True
    assert md["formats"]["mp4"]["qualities"] == ["best"] and md["quality_mode"] == "original"
    assert md["thumbnail"] is None  # untrusted host is not passed to the browser
    assert md["notes"]


def test_post_without_video_formats_is_unavailable():
    md = build_metadata({"id": "C1", "title": "photo", "formats": []}, Config(), True, "instagram")
    assert md["formats"]["mp4"]["available"] is False and md["formats"]["mp3"]["available"] is False


# ---------------------------------------------------------------- yt-dlp format selection (offline)
def _pick(spec, fmts):
    sel = yt_dlp.YoutubeDL({"quiet": True}).build_format_selector(spec)
    return [f["format_id"] for f in sel({"formats": fmts, "incomplete_formats": False})]


def test_watermark_free_selector_never_returns_labelled_formats():
    fmts = tt_formats()
    assert "dl720" not in _pick(video_format_selector("best", True), fmts)
    assert _pick(video_format_selector(720, True), fmts) == ["play720"]
    assert _pick(video_format_selector(540, True), fmts) == ["play540"]
    # No exact match -> nothing selected. yt-dlp then raises "Requested format is not available",
    # which translate_error maps to quality_unavailable. A different resolution is never substituted.
    assert _pick(video_format_selector(1080, True), fmts) == []
    assert _pick(video_format_selector("best", True), tt_formats(clean_heights=(), marked_heights=(720,))) == []
    assert translate_error(Exception("ERROR: Requested format is not available"), "tiktok").code == "quality_unavailable"


def test_run_download_rejects_watermarked_result_when_watermark_free(monkeypatch, tmp_path):
    class FakeYDL:
        def __init__(self, opts): self.opts = opts
        def __enter__(self): return self
        def __exit__(self, *a): return False
        def extract_info(self, url, download=True):
            (tmp_path / "media.mp4").write_bytes(b"x")
            return {"title": "t", "requested_formats": [{"format_note": "watermarked"}]}
    monkeypatch.setattr(downloader.yt_dlp, "YoutubeDL", FakeYDL)
    monkeypatch.setattr(downloader, "ffmpeg_available", lambda c=None: True)
    req = parse_download_request({"url": TT_URL, "format": "mp4", "watermark_free": True}, 192)
    job = type("J", (), {"request": req, "work_dir": str(tmp_path)})()
    with pytest.raises(MediaError) as exc:
        downloader.run_download(job, lambda *a, **k: None, Config(max_filesize_mb=10))
    assert exc.value.code == "watermark_free_unavailable"


# ---------------------------------------------------------------- error translation and logging
@pytest.mark.parametrize("platform,text,code", [
    ("instagram", "ERROR: [Instagram] X: Instagram sent an empty media response. Check if this post is accessible", "login_required"),
    ("instagram", "ERROR: [Instagram] X: Main webpage is locked behind the login page. Use --cookies", "login_required"),
    ("instagram", "ERROR: [Instagram] X: There is no video in this post", "no_video"),
    ("instagram", "ERROR: [Instagram] X: Video unavailable", "video_unavailable"),
    ("tiktok", "ERROR: [TikTok] 1: Your IP address is blocked from accessing this post", "source_blocked"),
    ("tiktok", "ERROR: [TikTok] 1: This post may not be comfortable for some audiences. Log in for access", "login_required"),
    ("tiktok", "ERROR: [TikTok] 1: Unable to extract aweme detail info", "extractor_failed"),
    ("tiktok", "ERROR: Unsupported URL: https://www.tiktok.com/foo", "unsupported_content"),
    ("youtube", "Sign in to confirm you're not a bot", "source_blocked"),
    ("tiktok", "something nobody has seen before", "extraction_failed"),
])
def test_platform_specific_error_translation(platform, text, code):
    err = translate_error(Exception(text), platform)
    assert err.code == code and "/home" not in err.message and "http" not in err.message


def test_redact_removes_query_strings():
    out = redact("failed https://www.instagram.com/reel/ABC/?igsh=SECRET&token=abc more")
    assert "SECRET" not in out and "token" not in out and "/reel/ABC/" in out


def test_operator_cookies_only_apply_to_youtube(tmp_path):
    cookies = tmp_path / "c.txt"; cookies.write_text("# Netscape")
    cfg = Config(cookies_file=str(cookies))
    assert "cookiefile" in downloader._base_opts(cfg, "youtube")
    assert "cookiefile" not in downloader._base_opts(cfg, "tiktok")
    assert "cookiefile" not in downloader._base_opts(cfg, "instagram")


# ---------------------------------------------------------------- API behaviour
def meta_for(url, config, platform="youtube"):
    base = fake_metadata(url, config, platform)
    if platform == "tiktok":
        base.update(platform="tiktok", platform_label="TikTok", quality_mode="selectable",
                    formats={"mp4": {"available": True, "qualities": ["540p", "720p", "best"], "reason": None},
                             "mp3": {"available": True, "bitrates": [128, 192, 256, 320], "reason": None}},
                    watermark_free={"applies": True, "available": True, "qualities": ["720p"], "reason": None})
    elif platform == "instagram":
        base.update(platform="instagram", platform_label="Instagram", quality_mode="original",
                    formats={"mp4": {"available": True, "qualities": ["best"], "reason": None},
                             "mp3": {"available": True, "bitrates": [128, 192, 256, 320], "reason": None}},
                    watermark_free={"applies": True, "available": False, "qualities": [],
                                    "reason": "Instagram does not provide a separate watermark-free file."})
    return base


def test_capabilities_list_platforms(make_app):
    app, _, _ = make_app(enabled_platforms=("youtube", "tiktok"))
    caps = app.test_client().get("/api/capabilities").json
    by_id = {p["id"]: p for p in caps["platforms"]}
    assert set(by_id) == {"youtube", "tiktok", "instagram"}
    assert by_id["tiktok"]["enabled"] is True and by_id["instagram"]["enabled"] is False
    assert by_id["instagram"]["watermark_free"] == "unavailable" and by_id["youtube"]["watermark_free"] == "not_applicable"


def test_metadata_endpoint_per_platform(make_app):
    app, _, _ = make_app(fetcher=meta_for)
    c = app.test_client()
    for url, platform in ((YT_URL, "youtube"), (TT_URL, "tiktok"), (IG_URL, "instagram")):
        md = c.post("/api/metadata", json={"url": url}).json["metadata"]
        assert md["platform"] == platform
    assert c.post("/api/metadata", json={"url": "https://vimeo.com/1"}).json["error"]["code"] == "unsupported_host"
    assert c.post("/api/metadata", json={"url": "https://www.instagram.com/stories/u/1/"}).json["error"]["code"] == "unsupported_content"


def test_unavailable_metadata_errors_pass_through_safely(make_app):
    def gone(url, cfg, platform="youtube"):
        raise MediaError("video_unavailable", "This content is unavailable, deleted, or the link has expired.", 404)
    app, _, _ = make_app(fetcher=gone)
    r = app.test_client().post("/api/metadata", json={"url": IG_URL})
    assert r.status_code == 404 and r.json["error"]["code"] == "video_unavailable"


def test_short_link_end_to_end_uses_injected_resolver(make_app):
    app, _, _ = make_app(fetcher=meta_for, link_resolver=lambda u: TT_URL)
    r = app.test_client().post("/api/metadata", json={"url": "https://vm.tiktok.com/ZMabc123/"})
    assert r.status_code == 200 and r.json["metadata"]["platform"] == "tiktok"


def test_platform_disabled_via_config(make_app):
    app, _, _ = make_app(fetcher=meta_for, enabled_platforms=("youtube",))
    r = app.test_client().post("/api/metadata", json={"url": IG_URL})
    assert r.status_code == 400 and r.json["error"]["code"] == "platform_disabled"


def test_watermark_free_unavailable_is_rejected_without_queueing(make_app):
    app, queue, _ = make_app(fetcher=meta_for)
    r = app.test_client().post("/api/downloads", json={"url": IG_URL, "format": "mp4", "watermark_free": True})
    assert r.status_code == 422 and r.json["error"]["code"] == "watermark_free_unavailable"
    assert "not changed" in r.json["error"]["message"] and queue.stats()["waiting"] == 0


def test_watermark_free_accepted_when_available_and_labelled_honestly(make_app):
    app, queue, _ = make_app(fetcher=meta_for)
    c = app.test_client()
    r = c.post("/api/downloads", json={"url": TT_URL, "format": "mp4", "quality": "720p", "watermark_free": True})
    assert r.status_code == 202
    job = r.json["job"]
    assert job["watermark_free"] is True and job["platform"] == "tiktok" and "labelled" in job["output_note"]
    assert queue.get(job["id"]).request.watermark_free is True
    # same media without the option is a different job and is labelled as the original
    r2 = c.post("/api/downloads", json={"url": TT_URL, "format": "mp4", "quality": "best"})
    assert r2.json["job"]["id"] != job["id"] and r2.json["job"]["watermark_free"] is False
    assert "may include" in r2.json["job"]["output_note"]


def test_watermark_free_quality_must_exist_in_clean_formats(make_app):
    app, _, _ = make_app(fetcher=meta_for)
    c = app.test_client()
    r = c.post("/api/downloads", json={"url": TT_URL, "format": "mp4", "quality": "540p", "watermark_free": True})
    assert r.status_code == 422 and r.json["error"]["code"] == "quality_unavailable"
    ok = c.post("/api/downloads", json={"url": TT_URL, "format": "mp4", "quality": "540p"})
    assert ok.status_code == 202  # 540p exists in the original, just not as a clean file


def test_unsupported_quality_for_non_youtube(make_app):
    app, _, _ = make_app(fetcher=meta_for)
    c = app.test_client()
    r = c.post("/api/downloads", json={"url": IG_URL, "format": "mp4", "quality": "720p"})
    assert r.status_code == 422 and r.json["error"]["code"] == "quality_unavailable"
    assert c.post("/api/downloads", json={"url": IG_URL, "format": "mp4", "quality": "7p"}).json["error"]["code"] == "invalid_quality"
    assert c.post("/api/downloads", json={"url": IG_URL, "format": "mp4", "quality": "best"}).status_code == 202


def test_invalid_watermark_field_is_a_400(make_app):
    app, _, _ = make_app(fetcher=meta_for)
    r = app.test_client().post("/api/downloads", json={"url": TT_URL, "format": "mp4", "watermark_free": "true"})
    assert r.status_code == 400 and r.json["error"]["code"] == "invalid_watermark_free"


def test_youtube_flow_still_works_unchanged(make_app):
    app, queue, _ = make_app(fetcher=meta_for)
    queue.start()
    c = app.test_client()
    r = c.post("/api/downloads", json={"url": YT_URL, "format": "mp4", "quality": "720p"})
    assert r.status_code == 202 and r.json["job"]["platform"] == "youtube" and r.json["job"]["watermark_free"] is False
    jid = r.json["job"]["id"]
    assert wait_for(lambda: c.get(f"/api/downloads/{jid}").json["job"]["status"] == "completed")
    assert c.get(f"/api/downloads/{jid}/file").data == b"fake-media-bytes"


def test_queue_limits_apply_across_platforms(make_app):
    app, queue, _ = make_app(fetcher=meta_for, max_waiting_jobs=1)
    c = app.test_client()
    assert c.post("/api/downloads", json={"url": TT_URL, "format": "mp3"}).status_code == 202
    r = c.post("/api/downloads", json={"url": IG_URL, "format": "mp3"})
    assert r.status_code == 503 and r.json["error"]["code"] == "queue_full"


def test_failed_tiktok_job_cleans_its_directory(make_app):
    import os
    err = MediaError("watermark_free_unavailable", "A watermark-free version could not be obtained for this video.")
    app, queue, config = make_app(fetcher=meta_for, runner=fake_runner_factory(fail_with=err))
    queue.start()
    c = app.test_client()
    jid = c.post("/api/downloads", json={"url": TT_URL, "format": "mp4", "watermark_free": True, "quality": "720p"}).json["job"]["id"]
    assert wait_for(lambda: c.get(f"/api/downloads/{jid}").json["job"]["status"] == "failed")
    assert c.get(f"/api/downloads/{jid}").json["job"]["error"]["code"] == "watermark_free_unavailable"
    assert wait_for(lambda: not any(os.scandir(config.temp_dir)))


def test_ytdlp_output_is_routed_through_redacting_logger():
    opts = downloader._base_opts(Config(), "instagram")
    assert isinstance(opts["logger"], downloader._YtdlpLogger)
    opts["logger"].error("boom https://x.example/a?token=SECRET")  # must not raise
