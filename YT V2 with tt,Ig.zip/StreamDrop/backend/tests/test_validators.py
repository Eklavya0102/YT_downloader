import pytest

from validators import (ValidationError, parse_bitrate, parse_download_request, parse_format, parse_quality,
                        parse_youtube_url, safe_filename)

ID = "dQw4w9WgXcQ"
GOOD = [
    f"https://www.youtube.com/watch?v={ID}",
    f"https://youtube.com/watch?v={ID}&t=10s",
    f"https://m.youtube.com/watch?v={ID}",
    f"https://music.youtube.com/watch?v={ID}",
    f"https://youtu.be/{ID}?si=abc",
    f"https://www.youtube.com/shorts/{ID}",
    f"https://www.youtube.com/embed/{ID}",
    f"http://www.youtube.com/watch?v={ID}",
]
BAD = [
    "", "   ", None, 123, "not a url", f"ftp://www.youtube.com/watch?v={ID}", f"file:///etc/passwd",
    "http://127.0.0.1/watch?v=" + ID, "http://localhost:5000/", "http://169.254.169.254/latest/meta-data",
    "http://[::1]/", "https://10.0.0.5/watch?v=" + ID, f"https://youtube.com.evil.com/watch?v={ID}",
    f"https://evil.com/?u=https://www.youtube.com/watch?v={ID}", f"https://www.youtube.com@evil.com/watch?v={ID}",
    f"https://user:pw@www.youtube.com/watch?v={ID}", f"https://www.youtube.com:8080/watch?v={ID}",
    "https://www.youtube.com/playlist?list=PL123", "https://www.youtube.com/watch?v=short",
    f"https://www.youtube.com/watch?v={ID}&v={ID}", "https://www.youtube.com/@channel",
    f"https://www.youtube.com/watch?v={ID}\nHost: evil", "https://www.youtube.com/watch?v=" + "a" * 3000,
]


@pytest.mark.parametrize("url", GOOD)
def test_accepts_supported_youtube_urls(url):
    vid, canonical = parse_youtube_url(url)
    assert vid == ID
    assert canonical == f"https://www.youtube.com/watch?v={ID}"


@pytest.mark.parametrize("url", BAD)
def test_rejects_unsafe_or_unsupported_urls(url):
    with pytest.raises(ValidationError):
        parse_youtube_url(url)


def test_format_and_quality_validation():
    assert parse_format("MP4") == "mp4" and parse_format("mp3") == "mp3"
    for bad in ("avi", "", None, "mp4; rm -rf /"):
        with pytest.raises(ValidationError):
            parse_format(bad)
    assert parse_quality("720p") == 720 and parse_quality("best") == "best" and parse_quality(None) == "best"
    for bad in ("999p", "720x", "-1", "1440p", "best;ls"):
        with pytest.raises(ValidationError):
            parse_quality(bad)
    assert parse_bitrate(None, 192) == 192 and parse_bitrate("320", 192) == 320
    with pytest.raises(ValidationError):
        parse_bitrate("999", 192)


def test_download_request_ignores_irrelevant_fields_per_format():
    req = parse_download_request({"url": GOOD[0], "format": "mp3", "quality": "garbage"}, 192)
    assert req.fmt == "mp3" and req.bitrate == 192
    with pytest.raises(ValidationError):
        parse_download_request([], 192)


def test_safe_filename_strips_path_and_control_characters():
    name = safe_filename("../../etc/passwd\x00<script>|:*?\"", " [720p]", "mp4")
    assert "/" not in name and "\\" not in name and "\x00" not in name and not name.startswith(".")
    assert name.endswith(" [720p].mp4")
    assert safe_filename("", "", "mp3") == "streamdrop.mp3"
    assert len(safe_filename("x" * 500, "", "mp4")) <= 110
