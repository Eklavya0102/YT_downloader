import threading

import pytest

from conftest import URL, fake_runner_factory, wait_for
from queue_manager import CannotCancelError, QueueFullError, TooManyJobsError
from validators import parse_download_request


def req(fmt="mp3", quality="best", url=URL):
    return parse_download_request({"url": url, "format": fmt, "quality": quality}, 192)


def other_url(n):
    return f"https://www.youtube.com/watch?v=abcdefghi{n:02d}"


def test_queue_full_after_max_waiting(make_app):
    gate = threading.Event()
    app, queue, _ = make_app(runner=fake_runner_factory(gate=gate), max_waiting_jobs=2)
    # workers intentionally not started: everything stays waiting
    queue.submit(req(url=other_url(1)), "a")
    queue.submit(req(url=other_url(2)), "b")
    with pytest.raises(QueueFullError) as exc:
        queue.submit(req(url=other_url(3)), "c")
    assert exc.value.retry_after > 0
    assert queue.stats()["waiting"] == 2
    gate.set()


def test_queue_full_http_response(make_app):
    app, queue, _ = make_app(max_waiting_jobs=1)
    c = app.test_client()
    ok = c.post("/api/downloads", json={"url": URL, "format": "mp3"})
    assert ok.status_code == 202 and ok.json["job"]["queue_position"] == 1
    # same client + same media -> deduplicated, not a new slot
    dup = c.post("/api/downloads", json={"url": URL, "format": "mp3"})
    assert dup.status_code == 200 and dup.json["duplicate"] is True and dup.json["job"]["id"] == ok.json["job"]["id"]


def test_queue_full_returns_503_with_retry_after(make_app):
    app, queue, _ = make_app(max_waiting_jobs=0)
    r = app.test_client().post("/api/downloads", json={"url": URL, "format": "mp3"})
    assert r.status_code == 503 and r.json["error"]["code"] == "queue_full" and int(r.headers["Retry-After"]) > 0


def test_per_client_cap(make_app):
    _, queue, _ = make_app(max_jobs_per_client=1)
    queue.submit(req(url=other_url(1)), "same")
    with pytest.raises(TooManyJobsError):
        queue.submit(req(url=other_url(2)), "same")
    queue.submit(req(url=other_url(2)), "different")


def test_status_transitions_and_single_active_job(make_app):
    gate = threading.Event()
    _, queue, _ = make_app(runner=fake_runner_factory(gate=gate), max_active_jobs=1)
    queue.start()
    j1, _ = queue.submit(req(url=other_url(1)), "a")
    j2, _ = queue.submit(req(url=other_url(2)), "b")
    assert wait_for(lambda: j1.status == "processing")
    assert j2.status == "queued" and queue.position(j2.id) == 1
    assert queue.stats()["active"] == 1
    gate.set()
    assert wait_for(lambda: j1.status == "completed" and j2.status == "completed")
    assert j1.progress.get("percent") == 100.0 and j1.stage == "ready"


def test_cancel_rules(make_app):
    gate = threading.Event()
    _, queue, config = make_app(runner=fake_runner_factory(gate=gate))
    queue.start()
    running, _ = queue.submit(req(url=other_url(1)), "a")
    waiting, _ = queue.submit(req(url=other_url(2)), "b")
    assert wait_for(lambda: running.status == "processing")
    with pytest.raises(CannotCancelError):
        queue.cancel(running.id)
    assert queue.cancel(waiting.id) == "cancelled"
    assert queue.get(waiting.id) is None
    gate.set()
    assert wait_for(lambda: running.status == "completed")
    assert queue.cancel(running.id) == "deleted"


def test_job_ids_are_unique_and_directories_isolated(make_app):
    _, queue, _ = make_app()
    jobs = [queue.submit(req(url=other_url(i)), f"c{i}")[0] for i in range(4)]
    assert len({j.id for j in jobs}) == 4 and len({j.work_dir for j in jobs}) == 4
