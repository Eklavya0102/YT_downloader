"""StreamDrop Flask API.  Gunicorn entry point: `app:app`."""
from __future__ import annotations

import json
import logging
import os
import re
import threading
import time
from typing import Callable, Optional

from flask import Flask, Response, jsonify, request
from flask_cors import CORS
from werkzeug.middleware.proxy_fix import ProxyFix

from cleanup import CleanupThread
from config import AUDIO_BITRATES, VIDEO_QUALITIES, Config
from downloader import MediaError, fetch_metadata, ffmpeg_available, resolve_short_url, run_download
from queue_manager import (
    COMPLETED, EXPIRED, CannotCancelError, InMemoryJobQueue, JobQueue, QueueFullError, TooManyJobsError,
)
from rate_limit import SlidingWindowLimiter
from validators import (JOB_ID_RE, PLATFORM_LABELS, MediaRef, ValidationError, parse_download_request,
                        parse_media_url)

log = logging.getLogger("streamdrop.api")


class JsonFormatter(logging.Formatter):
    """One JSON object per log line (easy to search in Render's log viewer)."""

    _skip = set(logging.LogRecord("", 0, "", 0, "", (), None).__dict__) | {"message", "asctime"}

    def format(self, record: logging.LogRecord) -> str:
        data = {"ts": self.formatTime(record, "%Y-%m-%dT%H:%M:%S"), "level": record.levelname,
                "logger": record.name, "msg": record.getMessage()}
        data.update({k: v for k, v in record.__dict__.items() if k not in self._skip})
        if record.exc_info:
            data["exc"] = self.formatException(record.exc_info)  # server logs only, never sent to clients
        return json.dumps(data, default=str)


def configure_logging(level: str) -> None:
    root = logging.getLogger()
    if not any(isinstance(h.formatter, JsonFormatter) for h in root.handlers):
        handler = logging.StreamHandler()
        handler.setFormatter(JsonFormatter())
        root.handlers = [handler]
    root.setLevel(getattr(logging, level, logging.INFO))


def error_response(code: str, message: str, status: int, **headers):
    resp = jsonify({"ok": False, "error": {"code": code, "message": message}})
    resp.status_code = status
    for key, value in headers.items():
        resp.headers[key.replace("_", "-")] = str(value)
    return resp


PLATFORM_CAPABILITIES = {
    "youtube": {"content_types": ["Single videos", "Shorts"], "quality_options": "standard ladder (360p to 1080p) when the video offers it",
                "watermark_free": "not_applicable"},
    "tiktok": {"content_types": ["Public videos", "Short links (vm.tiktok.com)"], "quality_options": "as provided by the video",
               "watermark_free": "per_video"},
    "instagram": {"content_types": ["Public Reels and video posts"], "quality_options": "as provided by the post",
                  "watermark_free": "unavailable"},
}


class MetadataService:
    """Metadata fetcher with a small TTL cache and a concurrency cap (protects the free instance)."""

    def __init__(self, config: Config, fetcher: Callable[..., dict]):
        self.config, self.fetcher = config, fetcher
        self._cache: dict[str, tuple[float, dict]] = {}
        self._lock = threading.Lock()
        self._slots = threading.BoundedSemaphore(2)

    def get(self, ref: MediaRef) -> dict:
        key, now = ref.cache_key, time.time()
        with self._lock:
            hit = self._cache.get(key)
            if hit and now - hit[0] < self.config.metadata_cache_seconds:
                return hit[1]
        if not self._slots.acquire(timeout=10):
            raise MediaError("busy", "The server is busy reading other videos. Try again in a moment.", 503)
        try:
            data = self.fetcher(ref.url, self.config, ref.platform)
        finally:
            self._slots.release()
        with self._lock:
            if len(self._cache) >= 128:
                self._cache.pop(min(self._cache, key=lambda k: self._cache[k][0]))
            self._cache[key] = (time.time(), data)
        return data


def create_app(
    config: Optional[Config] = None,
    *,
    queue: Optional[JobQueue] = None,
    metadata_fetcher: Optional[Callable[..., dict]] = None,
    link_resolver: Optional[Callable[[str], str]] = None,
    runner: Optional[Callable] = None,
    start_workers: bool = True,
) -> Flask:
    config = config or Config.from_env()
    configure_logging(config.log_level)
    app = Flask(__name__)
    app.config["JSON_SORT_KEYS"] = False
    app.config["MAX_CONTENT_LENGTH"] = 16 * 1024  # request bodies are tiny JSON
    if config.trust_proxy_hops:
        app.wsgi_app = ProxyFix(app.wsgi_app, x_for=config.trust_proxy_hops, x_proto=config.trust_proxy_hops)

    # ---- CORS: explicit origins only -------------------------------------------------
    origins: list = list(config.allowed_origins)
    if config.allowed_origin_regex:
        origins.append(re.compile(f"^(?:{config.allowed_origin_regex})$"))
    if origins:
        CORS(app, resources={r"/api/*": {
            "origins": origins, "methods": ["GET", "POST", "DELETE", "OPTIONS"],
            "allow_headers": ["Content-Type"], "expose_headers": ["Content-Disposition", "Retry-After"],
            "max_age": 600,
        }}, supports_credentials=False)
    else:
        log.warning("no ALLOWED_ORIGINS configured: cross-origin browser requests will be blocked")

    # ---- services ----------------------------------------------------------------------
    queue = queue or InMemoryJobQueue(config, runner or (lambda job, report: run_download(job, report, config)))
    metadata = MetadataService(config, metadata_fetcher or fetch_metadata)
    limiters = {
        "metadata": SlidingWindowLimiter(*config.rate_metadata),
        "downloads": SlidingWindowLimiter(*config.rate_downloads),
        "status": SlidingWindowLimiter(*config.rate_status),
    }
    app.extensions["streamdrop"] = {"queue": queue, "config": config, "metadata": metadata}
    if start_workers:
        queue.start()
        CleanupThread(queue, config.cleanup_interval_seconds).start()

    resolver = link_resolver or (lambda url: resolve_short_url(url, config.link_resolve_timeout_seconds))

    def client_id() -> str:
        return request.remote_addr or "unknown"

    def rate_limit(bucket: str) -> Optional[object]:
        allowed, retry = limiters[bucket].hit(client_id())
        if allowed:
            return None
        return error_response("rate_limited", f"Too many requests. Try again in {retry} seconds.", 429, Retry_After=retry)

    def json_body() -> dict:
        data = request.get_json(silent=True)
        if not isinstance(data, dict):
            raise ValidationError("invalid_body", "Request body must be a JSON object.")
        return data

    # ---- hooks and errors ----------------------------------------------------------------
    @app.after_request
    def security_headers(resp):
        resp.headers.setdefault("X-Content-Type-Options", "nosniff")
        resp.headers.setdefault("X-Frame-Options", "DENY")
        resp.headers.setdefault("Referrer-Policy", "no-referrer")
        resp.headers.setdefault("Content-Security-Policy", "default-src 'none'; frame-ancestors 'none'")
        resp.headers.setdefault("Cache-Control", "no-store")
        return resp

    @app.errorhandler(ValidationError)
    def _validation(exc):
        return error_response(exc.code, exc.message, exc.status)

    @app.errorhandler(MediaError)
    def _media(exc):
        return error_response(exc.code, exc.message, exc.status)

    @app.errorhandler(404)
    def _404(_):
        return error_response("not_found", "Resource not found.", 404)

    @app.errorhandler(405)
    def _405(_):
        return error_response("method_not_allowed", "Method not allowed.", 405)

    @app.errorhandler(413)
    def _413(_):
        return error_response("payload_too_large", "Request body too large.", 413)

    @app.errorhandler(Exception)
    def _500(exc):
        log.exception("unhandled error")
        return error_response("internal_error", "Unexpected server error.", 500)

    # ---- routes --------------------------------------------------------------------------
    @app.get("/api/health")
    def health():
        return jsonify({"ok": True, "status": "ok", "version": config.version})

    @app.get("/api/capabilities")
    def capabilities():
        return jsonify({
            "ok": True,
            "formats": {
                "mp4": {"qualities": [f"{q}p" for q in VIDEO_QUALITIES] + ["best"]},
                "mp3": {"bitrates": list(AUDIO_BITRATES), "default_bitrate": config.default_audio_bitrate},
            },
            "platforms": [
                {"id": pid, "label": PLATFORM_LABELS[pid], "enabled": pid in config.enabled_platforms, **info}
                for pid, info in PLATFORM_CAPABILITIES.items()
            ],
            "ffmpeg": ffmpeg_available(config),
            "queue": queue.stats(),
            "limits": {"max_duration_seconds": config.max_duration_seconds, "max_filesize_mb": config.max_filesize_mb,
                       "job_ttl_seconds": config.job_ttl_seconds},
        })

    @app.post("/api/metadata")
    def post_metadata():
        if (limited := rate_limit("metadata")):
            return limited
        ref = parse_media_url(json_body().get("url"), resolver, config.enabled_platforms)
        return jsonify({"ok": True, "metadata": metadata.get(ref)})

    @app.post("/api/downloads")
    def create_download():
        if (limited := rate_limit("downloads")):
            return limited
        req = parse_download_request(json_body(), config.default_audio_bitrate, resolver, config.enabled_platforms)
        if not ffmpeg_available(config):
            raise MediaError("ffmpeg_missing", "Media processing is unavailable on this server.", 503)

        # Re-verify against genuine metadata server-side; never trust the browser's view.
        info = metadata.get(MediaRef(req.platform, req.video_id, req.url))
        fmt_info = info["formats"][req.fmt]
        if not fmt_info["available"]:
            raise MediaError("format_unavailable", fmt_info["reason"] or "This format is not available.", 422)

        offered = [q for q in fmt_info.get("qualities", []) if q != "best"]
        if req.watermark_free:
            wm = info.get("watermark_free") or {}
            if not wm.get("available"):
                # Reject this specific mode. Never silently fall back to the watermarked original.
                raise MediaError("watermark_free_unavailable",
                                 (wm.get("reason") or "A watermark-free version is not available for this video.")
                                 + " Your selection was not changed; request the original version to continue.", 422)
            offered = [q for q in wm.get("qualities", [])]
        if req.fmt == "mp4" and req.quality != "best" and f"{req.quality}p" not in offered:
            listed = ", ".join(offered) or "none (only the original quality is offered)"
            raise MediaError("quality_unavailable",
                             f"{req.quality}p is not available for this video. Available: {listed}, best.", 422)

        try:
            job, created = queue.submit(req, client_id())
        except QueueFullError as exc:
            return error_response("queue_full", f"The queue is full. Please retry in about {exc.retry_after} seconds.",
                                  503, Retry_After=exc.retry_after)
        except TooManyJobsError:
            return error_response("too_many_jobs", "You already have the maximum number of active jobs. Wait for one to finish.", 429)
        resp = jsonify({"ok": True, "duplicate": not created, "job": job.public(queue.position(job.id)), "queue": queue.stats()})
        resp.status_code = 202 if created else 200
        return resp

    def lookup(job_id: str):
        if not JOB_ID_RE.fullmatch(job_id):
            return None
        return queue.get(job_id)

    @app.get("/api/downloads/<job_id>")
    def get_download(job_id: str):
        if (limited := rate_limit("status")):
            return limited
        job = lookup(job_id)
        if job is None:
            return error_response("job_not_found", "Job not found. It may have expired or the server restarted.", 404)
        return jsonify({"ok": True, "job": job.public(queue.position(job.id)), "queue": queue.stats()})

    @app.get("/api/downloads/<job_id>/file")
    def get_file(job_id: str):
        if (limited := rate_limit("status")):
            return limited
        job = lookup(job_id)
        if job is None:
            return error_response("job_not_found", "Job not found. It may have expired or the server restarted.", 404)
        if job.status == EXPIRED:
            return error_response("job_expired", "This download has expired. Please start a new one.", 410)
        if job.status != COMPLETED or not job.file_path:
            return error_response("not_ready", "The file is not ready yet.", 409)
        try:
            size = os.path.getsize(job.file_path)
            fh = open(job.file_path, "rb")
        except OSError:
            return error_response("job_expired", "This download has expired. Please start a new one.", 410)

        def stream():
            # werkzeug skips call_on_close for send_file(), so stream manually and only
            # start the short post-delivery grace period when the whole file was sent.
            sent_all = False
            try:
                with fh:
                    while chunk := fh.read(256 * 1024):
                        yield chunk
                sent_all = True
            finally:
                if sent_all:
                    queue.mark_delivered(job_id)

        resp = Response(stream(), mimetype=job.mimetype or "application/octet-stream")
        resp.headers.set("Content-Disposition", "attachment", filename=job.filename)  # safe, RFC 6266 encoded
        resp.headers["Content-Length"] = str(size)
        return resp

    @app.delete("/api/downloads/<job_id>")
    def delete_download(job_id: str):
        if (limited := rate_limit("status")):
            return limited
        if not JOB_ID_RE.fullmatch(job_id):
            return error_response("job_not_found", "Job not found.", 404)
        try:
            outcome = queue.cancel(job_id)
        except KeyError:
            return error_response("job_not_found", "Job not found.", 404)
        except CannotCancelError:
            return error_response("cannot_cancel", "Processing has already started and cannot be stopped safely.", 409)
        return jsonify({"ok": True, "result": outcome})

    return app


# Module-level instance for Gunicorn (`app:app`). Tests set STREAMDROP_SKIP_DEFAULT_APP=1.
app = create_app() if (__name__ != "__main__" and os.environ.get("STREAMDROP_SKIP_DEFAULT_APP") != "1") else None

if __name__ == "__main__":
    # Local development server only. Production uses Gunicorn (see Dockerfile).
    import os
    create_app().run(host="127.0.0.1", port=int(os.environ.get("PORT", "5000")), debug=False, threaded=True)
