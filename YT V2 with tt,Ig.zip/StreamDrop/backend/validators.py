"""Input validation. The backend never trusts IDs, URLs or metadata sent by the browser.

Supported platforms: YouTube, TikTok, Instagram. Every URL is parsed against an exact-host
allowlist, reduced to an ID, and rebuilt as a canonical URL; only the canonical URL ever reaches yt-dlp.
"""
from __future__ import annotations

import re
import unicodedata
from dataclasses import dataclass
from typing import Callable, Iterable, Optional, Union
from urllib.parse import parse_qs, urlsplit

from config import AUDIO_BITRATES, VIDEO_QUALITIES

YOUTUBE, TIKTOK, INSTAGRAM = "youtube", "tiktok", "instagram"
PLATFORMS = (YOUTUBE, TIKTOK, INSTAGRAM)
PLATFORM_LABELS = {YOUTUBE: "YouTube", TIKTOK: "TikTok", INSTAGRAM: "Instagram"}

# Exact-match allowlists. IP literals, localhost, and look-alike hosts can never match.
ALLOWED_HOSTS = frozenset(  # YouTube (name kept for backwards compatibility)
    {"youtube.com", "www.youtube.com", "m.youtube.com", "music.youtube.com", "youtu.be"}
)
TIKTOK_HOSTS = frozenset({"tiktok.com", "www.tiktok.com", "m.tiktok.com"})
TIKTOK_SHORT_HOSTS = frozenset({"vm.tiktok.com", "vt.tiktok.com"})
INSTAGRAM_HOSTS = frozenset({"instagram.com", "www.instagram.com"})
HOST_PLATFORM = {
    **{h: YOUTUBE for h in ALLOWED_HOSTS},
    **{h: TIKTOK for h in TIKTOK_HOSTS | TIKTOK_SHORT_HOSTS},
    **{h: INSTAGRAM for h in INSTAGRAM_HOSTS},
}

VIDEO_ID_RE = re.compile(r"^[A-Za-z0-9_-]{11}$")
JOB_ID_RE = re.compile(r"^[A-Za-z0-9_-]{20,64}$")
TIKTOK_ID_RE = re.compile(r"^\d{8,25}$")
TIKTOK_USER_RE = re.compile(r"^@[A-Za-z0-9._]{1,64}$")
TIKTOK_SHORT_RE = re.compile(r"^[A-Za-z0-9_-]{4,32}$")
IG_CODE_RE = re.compile(r"^[A-Za-z0-9_-]{5,24}$")
IG_USER_RE = re.compile(r"^[A-Za-z0-9._]{1,30}$")
PATH_ID_PREFIXES = ("shorts", "embed", "live", "v")
FORMATS = ("mp4", "mp3")
MAX_URL_LENGTH = 2048
MIN_OTHER_HEIGHT, MAX_OTHER_HEIGHT = 144, 4320

# resolver(short_url) -> final URL. Supplied by the app so validation stays free of network I/O.
Resolver = Callable[[str], str]


class ValidationError(Exception):
    """Raised for invalid client input. Carries a stable machine code and a safe message."""

    def __init__(self, code: str, message: str, status: int = 400):
        super().__init__(message)
        self.code = code
        self.message = message
        self.status = status


@dataclass(frozen=True)
class MediaRef:
    platform: str
    media_id: str
    url: str  # canonical URL rebuilt by the server

    @property
    def cache_key(self) -> str:
        return f"{self.platform}:{self.media_id}"


@dataclass(frozen=True)
class DownloadRequest:
    url: str
    video_id: str
    fmt: str
    quality: Union[int, str]  # height in pixels, or "best" (ignored for mp3)
    bitrate: int
    platform: str = YOUTUBE
    watermark_free: bool = False

    @property
    def fingerprint(self) -> str:
        return f"{self.platform}:{self.video_id}:{self.fmt}:{self.quality}:{self.bitrate}:{int(self.watermark_free)}"


def canonical_url(video_id: str) -> str:
    return f"https://www.youtube.com/watch?v={video_id}"


def _split(raw: object, hosts: Iterable[str], unsupported_message: str):
    """Shared URL sanity checks. Returns (SplitResult, lowercase_host)."""
    if not isinstance(raw, str):
        raise ValidationError("invalid_url", "A URL string is required.")
    url = raw.strip()
    if not url or len(url) > MAX_URL_LENGTH:
        raise ValidationError("invalid_url", "Enter a valid video link.")
    if any(ord(ch) < 33 or ord(ch) == 127 for ch in url):
        raise ValidationError("invalid_url", "The URL contains invalid characters.")
    try:
        parts = urlsplit(url)
        port = parts.port
    except ValueError:
        raise ValidationError("invalid_url", "Enter a valid video link.")
    if parts.scheme not in ("http", "https"):
        raise ValidationError("invalid_url", "Only http(s) links are supported.")
    if parts.username or parts.password:
        raise ValidationError("invalid_url", "URLs with credentials are not allowed.")
    if port not in (None, 80, 443):
        raise ValidationError("invalid_url", "Unexpected port in URL.")
    host = (parts.hostname or "").lower()
    if host not in hosts:
        raise ValidationError("unsupported_host", unsupported_message)
    return parts, host


def parse_youtube_url(raw: object) -> tuple[str, str]:
    """Return (video_id, canonical_url) or raise ValidationError."""
    parts, host = _split(raw, ALLOWED_HOSTS, "Only YouTube links are supported.")
    video_id = None
    segments = [s for s in parts.path.split("/") if s]
    if host == "youtu.be":
        if len(segments) == 1:
            video_id = segments[0]
    elif segments == ["watch"]:
        values = parse_qs(parts.query).get("v", [])
        if len(values) == 1:
            video_id = values[0]
    elif len(segments) == 2 and segments[0] in PATH_ID_PREFIXES:
        video_id = segments[1]

    if not video_id or not VIDEO_ID_RE.fullmatch(video_id):
        raise ValidationError(
            "unsupported_url", "Use a link to a single YouTube video (playlists and channels are not supported)."
        )
    return video_id, canonical_url(video_id)


# ---- TikTok -----------------------------------------------------------------------------------
def _tiktok_full(segments: list[str]) -> MediaRef:
    if len(segments) == 3 and TIKTOK_USER_RE.fullmatch(segments[0]):
        if segments[1] == "video" and TIKTOK_ID_RE.fullmatch(segments[2]):
            return MediaRef(TIKTOK, segments[2], f"https://www.tiktok.com/{segments[0]}/video/{segments[2]}")
        if segments[1] == "photo":
            raise ValidationError("unsupported_content", "TikTok photo posts are not supported. Use a link to a video.")
    if len(segments) == 1 and segments[0].startswith("@"):
        raise ValidationError("unsupported_content", "That looks like a TikTok profile. Use a link to a single video.")
    raise ValidationError("unsupported_url", "Use a link to a single TikTok video (tiktok.com/@user/video/…).")


def _parse_tiktok(parts, host: str, resolver: Optional[Resolver]) -> MediaRef:
    segments = [s for s in parts.path.split("/") if s]
    is_short = host in TIKTOK_SHORT_HOSTS or (host in TIKTOK_HOSTS and len(segments) == 2 and segments[0] == "t")
    if not is_short:
        return _tiktok_full(segments)
    code = segments[-1] if segments else ""
    if (host in TIKTOK_SHORT_HOSTS and len(segments) != 1) or not TIKTOK_SHORT_RE.fullmatch(code):
        raise ValidationError("unsupported_url", "That TikTok short link looks invalid.")
    if resolver is None:
        raise ValidationError("unsupported_url", "Short links can't be resolved here. Open the video and copy its full link.")
    short = f"https://{host}/{code}" if host in TIKTOK_SHORT_HOSTS else f"https://{host}/t/{code}"
    target = resolver(short)  # raises ValidationError on failure
    inner, inner_host = _split(target, TIKTOK_HOSTS, "The short link did not lead to a TikTok video.")
    if inner.scheme != "https":
        raise ValidationError("unsupported_url", "The short link did not lead to a TikTok video.")
    inner_segments = [s for s in inner.path.split("/") if s]
    if inner_segments[:1] == ["t"]:
        raise ValidationError("unsupported_url", "The short link did not lead to a TikTok video.")
    return _tiktok_full(inner_segments)


# ---- Instagram --------------------------------------------------------------------------------
IG_KINDS = ("reel", "reels", "p", "tv")


def _parse_instagram(parts) -> MediaRef:
    segments = [s for s in parts.path.split("/") if s]
    if not segments:
        raise ValidationError("unsupported_url", "Use a link to a single Instagram Reel or video post.")
    if segments[0] == "stories":
        raise ValidationError("unsupported_content", "Instagram Stories need a login and are not supported.")
    if segments[0] == "share":
        raise ValidationError("unsupported_url", "Share links are not supported. Open the Reel and copy its regular link.")
    if len(segments) == 3 and IG_USER_RE.fullmatch(segments[0]) and segments[1] in IG_KINDS:
        segments = segments[1:]  # /username/reel/CODE
    if len(segments) == 2 and segments[0] in IG_KINDS and segments[1] != "audio" and IG_CODE_RE.fullmatch(segments[1]):
        kind = "reel" if segments[0] == "reels" else segments[0]
        return MediaRef(INSTAGRAM, segments[1], f"https://www.instagram.com/{kind}/{segments[1]}/")
    if len(segments) == 1 and IG_USER_RE.fullmatch(segments[0]):
        raise ValidationError("unsupported_content", "That looks like an Instagram profile. Use a link to a single Reel or video post.")
    raise ValidationError("unsupported_url", "Use a link to a single Instagram Reel or video post (instagram.com/reel/… or /p/…).")


def detect_platform(raw: object) -> Optional[str]:
    """Best-effort platform detection from the hostname alone (no path validation)."""
    try:
        host = (urlsplit(raw.strip()).hostname or "").lower() if isinstance(raw, str) else ""
    except ValueError:
        return None
    return HOST_PLATFORM.get(host)


def parse_media_url(raw: object, resolver: Optional[Resolver] = None, enabled: Optional[Iterable[str]] = None) -> MediaRef:
    """Detect the platform, validate the URL, and return a canonical MediaRef."""
    parts, host = _split(raw, HOST_PLATFORM, "Only YouTube, TikTok and Instagram links are supported.")
    platform = HOST_PLATFORM[host]
    if enabled is not None and platform not in set(enabled):
        raise ValidationError("platform_disabled", f"{PLATFORM_LABELS[platform]} downloads are turned off on this server.")
    if platform == YOUTUBE:
        video_id, url = parse_youtube_url(raw)
        return MediaRef(YOUTUBE, video_id, url)
    if platform == TIKTOK:
        return _parse_tiktok(parts, host, resolver)
    return _parse_instagram(parts)


# ---- Other fields -----------------------------------------------------------------------------
def parse_format(raw: object) -> str:
    fmt = raw.strip().lower() if isinstance(raw, str) else ""
    if fmt not in FORMATS:
        raise ValidationError("invalid_format", f"Format must be one of: {', '.join(FORMATS)}.")
    return fmt


def parse_quality(raw: object, platform: str = YOUTUBE) -> Union[int, str]:
    """YouTube accepts only the standard heights. TikTok/Instagram accept any plausible height;
    the endpoint then checks it against what that specific video really offers."""
    if raw is None:
        return "best"
    value = str(raw).strip().lower()
    if value == "best":
        return "best"
    match = re.fullmatch(r"(\d{3,4})p?", value)
    if match:
        height = int(match.group(1))
        if platform == YOUTUBE and height in VIDEO_QUALITIES:
            return height
        if platform != YOUTUBE and MIN_OTHER_HEIGHT <= height <= MAX_OTHER_HEIGHT:
            return height
    if platform == YOUTUBE:
        allowed = ", ".join(f"{q}p" for q in VIDEO_QUALITIES)
        raise ValidationError("invalid_quality", f"Quality must be one of: {allowed}, best.")
    raise ValidationError("invalid_quality", "Quality must be a height such as 720p, or best.")


def parse_bitrate(raw: object, default: int) -> int:
    if raw is None or raw == "":
        return default
    try:
        value = int(str(raw).lower().replace("kbps", "").strip())
    except ValueError:
        raise ValidationError("invalid_bitrate", "Invalid audio bitrate.")
    if value not in AUDIO_BITRATES:
        raise ValidationError(
            "invalid_bitrate", f"Audio bitrate must be one of: {', '.join(map(str, AUDIO_BITRATES))} kbps."
        )
    return value


def parse_download_request(
    data: object, default_bitrate: int, resolver: Optional[Resolver] = None, enabled: Optional[Iterable[str]] = None
) -> DownloadRequest:
    if not isinstance(data, dict):
        raise ValidationError("invalid_body", "Request body must be a JSON object.")
    ref = parse_media_url(data.get("url"), resolver, enabled)
    fmt = parse_format(data.get("format"))
    quality = parse_quality(data.get("quality"), ref.platform) if fmt == "mp4" else "best"
    bitrate = parse_bitrate(data.get("audio_bitrate"), default_bitrate) if fmt == "mp3" else default_bitrate

    wm = data.get("watermark_free", False)
    if not isinstance(wm, bool):
        raise ValidationError("invalid_watermark_free", "watermark_free must be true or false.")
    if wm and ref.platform == YOUTUBE:
        raise ValidationError("invalid_watermark_free", "The watermark-free option does not apply to YouTube.")
    if wm and fmt != "mp4":
        raise ValidationError("invalid_watermark_free", "The watermark-free option applies to video downloads only.")
    return DownloadRequest(url=ref.url, video_id=ref.media_id, fmt=fmt, quality=quality, bitrate=bitrate,
                           platform=ref.platform, watermark_free=wm)


def safe_filename(title: object, suffix: str, ext: str) -> str:
    """Build a download filename from untrusted metadata: no separators, controls or leading dots."""
    text = unicodedata.normalize("NFKC", str(title or ""))
    text = re.sub(r"[^\w\-. ()\[\]]+", "", text, flags=re.UNICODE)
    text = re.sub(r"\s+", " ", text).strip(" ._-")[:100].strip(" ._-")
    base = text or "streamdrop"
    return f"{base}{suffix}.{ext}"
