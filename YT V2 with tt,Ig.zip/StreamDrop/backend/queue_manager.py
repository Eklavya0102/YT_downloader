"""Bounded job queue.

`JobQueue` is the interface the Flask app depends on. `InMemoryJobQueue` is a single-process
implementation suitable for a limited beta on one instance:

  * jobs live in memory, so they are LOST on restart, redeploy, or free-tier sleep;
  * it is NOT shared between multiple instances or Gunicorn workers (run exactly one worker);
  * a Redis-backed implementation with separate worker processes can replace it later by
    implementing the same interface.
"""
from __future__ import annotations

import logging
import secrets
import tempfile
import threading
import time
from abc import ABC, abstractmethod
from collections import deque
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable, Deque, Dict, Optional

from cleanup import purge_orphans, remove_job_dir
from config import Config
from downloader import MediaError
from validators import DownloadRequest

log = logging.getLogger("streamdrop.queue")

QUEUED, PROCESSING, COMPLETED, FAILED, EXPIRED = "queued", "processing", "completed", "failed", "expired"

STAGE_LABELS = {
    "queued": "Waiting in queue",
    "fetching": "Fetching media",
    "downloading": "Downloading media",
    "merging": "Merging audio and video",
    "converting": "Converting to MP3",
    "finalizing": "Preparing the final file",
    "ready": "Ready to download",
    "failed": "Failed",
    "expired": "Expired",
}


class QueueFullError(Exception):
    def __init__(self, retry_after: int = 30):
        super().__init__("queue full")
        self.retry_after = retry_after


class TooManyJobsError(Exception):
    pass


class CannotCancelError(Exception):
    pass


@dataclass
class Job:
    id: str
    request: DownloadRequest
    client_id: str
    work_dir: str
    status: str = QUEUED
    stage: str = "queued"
    progress: dict = field(default_factory=dict)
    created_at: float = field(default_factory=time.time)
    started_at: Optional[float] = None
    finished_at: Optional[float] = None
    expires_at: Optional[float] = None
    filename: Optional[str] = None
    file_path: Optional[str] = None
    size_bytes: Optional[int] = None
    mimetype: Optional[str] = None
    error_code: Optional[str] = None
    error_message: Optional[str] = None
    title: Optional[str] = None

    def _output_note(self) -> Optional[str]:
        """Honest description of what the delivered file is. Never claims more than was verified."""
        req = self.request
        if req.fmt != "mp4":
            return None
        if req.platform == "tiktok":
            return ("Version not labelled as watermarked by the source" if req.watermark_free
                    else "Original version. It may include TikTok's watermark.")
        if req.platform == "instagram":
            return "Original media as served by Instagram."
        return None

    def public(self, position: Optional[int] = None) -> dict:
        """Client-safe view. Never includes filesystem paths."""
        data = {
            "id": self.id,
            "status": self.status,
            "stage": self.stage,
            "stage_label": STAGE_LABELS.get(self.stage, self.stage),
            "format": self.request.fmt,
            "quality": self.request.quality if self.request.fmt == "mp4" else None,
            "audio_bitrate": self.request.bitrate if self.request.fmt == "mp3" else None,
            "progress": dict(self.progress),
            "platform": self.request.platform,
            "watermark_free": self.request.watermark_free if self.request.fmt == "mp4" else None,
            "output_note": self._output_note(),
            "created_at": int(self.created_at),
            "expires_at": int(self.expires_at) if self.expires_at else None,
        }
        if self.status == QUEUED and position is not None:
            data["queue_position"] = position
        if self.status == COMPLETED:
            data["filename"] = self.filename
            data["size_bytes"] = self.size_bytes
        if self.status == FAILED:
            data["error"] = {"code": self.error_code, "message": self.error_message}
        return data


# runner(job, report) -> {"path", "filename", "size", "mimetype"}; raises MediaError on failure.
Runner = Callable[[Job, Callable[..., None]], dict]


class JobQueue(ABC):
    @abstractmethod
    def start(self) -> None: ...

    @abstractmethod
    def shutdown(self) -> None: ...

    @abstractmethod
    def submit(self, request: DownloadRequest, client_id: str) -> tuple[Job, bool]:
        """Return (job, created). Raises QueueFullError / TooManyJobsError."""

    @abstractmethod
    def get(self, job_id: str) -> Optional[Job]: ...

    @abstractmethod
    def position(self, job_id: str) -> Optional[int]: ...

    @abstractmethod
    def cancel(self, job_id: str) -> str:
        """Cancel a waiting job or delete a finished one. Raises CannotCancelError when processing."""

    @abstractmethod
    def mark_delivered(self, job_id: str) -> None: ...

    @abstractmethod
    def sweep(self, now: Optional[float] = None) -> None: ...

    @abstractmethod
    def stats(self) -> dict: ...


class InMemoryJobQueue(JobQueue):
    def __init__(self, config: Config, runner: Runner):
        self.config = config
        self.runner = runner
        self._jobs: Dict[str, Job] = {}
        self._waiting: Deque[str] = deque()
        self._cond = threading.Condition()
        self._stop = False
        self._threads: list[threading.Thread] = []
        Path(config.temp_dir).mkdir(parents=True, exist_ok=True)

    # ---- lifecycle -------------------------------------------------------------------
    def start(self) -> None:
        # Jobs do not survive restarts, so anything left on disk is an orphan.
        purge_orphans(self.config.temp_dir, keep=set(), min_age_seconds=0)
        for i in range(self.config.max_active_jobs):
            t = threading.Thread(target=self._worker, name=f"streamdrop-worker-{i}", daemon=True)
            t.start()
            self._threads.append(t)

    def shutdown(self) -> None:
        with self._cond:
            self._stop = True
            self._cond.notify_all()

    # ---- public API --------------------------------------------------------------------
    def submit(self, request: DownloadRequest, client_id: str) -> tuple[Job, bool]:
        with self._cond:
            live = (QUEUED, PROCESSING)
            for job in self._jobs.values():  # duplicate submission: reuse the live job
                if job.client_id == client_id and job.status in live and job.request.fingerprint == request.fingerprint:
                    return job, False
            if sum(1 for j in self._jobs.values() if j.client_id == client_id and j.status in live) >= self.config.max_jobs_per_client:
                raise TooManyJobsError()
            if len(self._waiting) >= self.config.max_waiting_jobs:
                raise QueueFullError(retry_after=30)
            work_dir = tempfile.mkdtemp(prefix="job_", dir=self.config.temp_dir)  # mode 0700
            job = Job(id=secrets.token_urlsafe(24), request=request, client_id=client_id, work_dir=work_dir)
            self._jobs[job.id] = job
            self._waiting.append(job.id)
            self._cond.notify()
            log.info("job queued", extra={"job_id": job.id, "fmt": request.fmt})
            return job, True

    def get(self, job_id: str) -> Optional[Job]:
        with self._cond:
            return self._jobs.get(job_id)

    def position(self, job_id: str) -> Optional[int]:
        with self._cond:
            try:
                return list(self._waiting).index(job_id) + 1
            except ValueError:
                return None

    def cancel(self, job_id: str) -> str:
        with self._cond:
            job = self._jobs.get(job_id)
            if job is None:
                raise KeyError(job_id)
            if job.status == PROCESSING:
                raise CannotCancelError()
            was_queued = job.status == QUEUED
            if was_queued:
                self._waiting.remove(job_id)
            del self._jobs[job_id]
        remove_job_dir(job.work_dir, self.config.temp_dir)
        return "cancelled" if was_queued else "deleted"

    def mark_delivered(self, job_id: str) -> None:
        with self._cond:
            job = self._jobs.get(job_id)
            if job and job.status == COMPLETED:
                job.expires_at = min(job.expires_at or float("inf"), time.time() + self.config.delivered_grace_seconds)

    def sweep(self, now: Optional[float] = None) -> None:
        now = now if now is not None else time.time()
        to_clean: list[str] = []
        with self._cond:
            for job_id, job in list(self._jobs.items()):
                if job.status == COMPLETED and job.expires_at and job.expires_at <= now:
                    job.status, job.stage, job.file_path = EXPIRED, "expired", None
                    job.finished_at = now
                    to_clean.append(job.work_dir)
                elif job.status in (EXPIRED, FAILED) and (job.finished_at or job.created_at) + self.config.record_retention_seconds <= now:
                    del self._jobs[job_id]
            keep = {str(Path(j.work_dir).resolve()) for j in self._jobs.values() if j.status in (QUEUED, PROCESSING, COMPLETED)}
        for path in to_clean:
            remove_job_dir(path, self.config.temp_dir)
        purge_orphans(self.config.temp_dir, keep=keep, min_age_seconds=300)

    def stats(self) -> dict:
        with self._cond:
            processing = sum(1 for j in self._jobs.values() if j.status == PROCESSING)
            return {
                "active": processing,
                "waiting": len(self._waiting),
                "max_active": self.config.max_active_jobs,
                "max_waiting": self.config.max_waiting_jobs,
                "durable": False,
            }

    # ---- worker ------------------------------------------------------------------------
    def _report(self, job: Job):
        def report(stage: Optional[str] = None, **progress) -> None:
            with self._cond:
                if stage:
                    job.stage = stage
                    if "percent" not in progress:
                        job.progress = {}  # new stage: drop stale numbers rather than show wrong ones
                if progress:
                    job.progress = {**job.progress, **progress}
        return report

    def _worker(self) -> None:
        while True:
            with self._cond:
                while not self._waiting and not self._stop:
                    self._cond.wait(timeout=1.0)
                if self._stop:
                    return
                job = self._jobs[self._waiting.popleft()]
                job.status, job.stage, job.started_at = PROCESSING, "fetching", time.time()
            self._run(job)

    def _run(self, job: Job) -> None:
        try:
            result = self.runner(job, self._report(job))
            with self._cond:
                now = time.time()
                job.status, job.stage = COMPLETED, "ready"
                job.progress = {"percent": 100.0}
                job.file_path, job.filename = result["path"], result["filename"]
                job.size_bytes, job.mimetype = result.get("size"), result.get("mimetype")
                job.finished_at, job.expires_at = now, now + self.config.job_ttl_seconds
            log.info("job completed", extra={"job_id": job.id})
        except MediaError as exc:
            self._fail(job, exc.code, exc.message)
        except Exception:
            log.exception("job crashed", extra={"job_id": job.id})
            self._fail(job, "internal_error", "Something went wrong while processing this media.")

    def _fail(self, job: Job, code: str, message: str) -> None:
        with self._cond:
            job.status, job.stage, job.progress = FAILED, "failed", {}
            job.error_code, job.error_message, job.finished_at = code, message, time.time()
        remove_job_dir(job.work_dir, self.config.temp_dir)
