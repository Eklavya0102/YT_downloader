"""yt-dlp integration: metadata extraction and media processing. No shell, no user-supplied args.

Platform support is whatever the installed yt-dlp extractors can legitimately retrieve for PUBLIC
content. Nothing here bypasses logins, private accounts, DRM or anti-abuse systems.
"""
from __future__ import annotations

import logging
import re
import shutil
import urllib.error
import urllib.request
from pathlib import Path
from typing import Callable, Optional
from urllib.parse import urljoin, urlsplit

import yt_dlp
from yt_dlp.utils import DownloadError, ExtractorError

from config import AUDIO_BITRATES, VIDEO_QUALITIES, Config
from validators import INSTAGRAM, PLATFORM_LABELS, TIKTOK, TIKTOK_HOSTS, YOUTUBE, ValidationError, safe_filename

log = logging.getLogger("streamdrop.downloader")

# Thumbnail hosts we are willing to hand to the browser, per platform.
THUMB_SUFFIXES = {
    YOUTUBE: ("ytimg.com", "ggpht.com"),
    TIKTOK: ("tiktokcdn.com", "tiktokcdn-us.com", "tiktokv.com", "muscdn.com"),
    INSTAGRAM: ("cdninstagram.com", "fbcdn.net"),
}
PLATFORM_NOTES = {
    YOUTUBE: [],
    TIKTOK: ["Only public videos are supported. Availability depends on TikTok and can change without notice."],
    INSTAGRAM: ["Only public Reels and video posts that open without logging in are supported. "
                "Availability depends on Instagram and can change without notice."],
}
_QUERY_RE = re.compile(r"\?[^\s'\"<>]*")


def redact(text: str, limit: int = 300) -> str:
    """Strip URL query strings (tokens, tracking ids) before anything reaches the logs."""
    return _QUERY_RE.sub("?<redacted>", str(text))[:limit]


class MediaError(Exception):
    """A failure that is safe to show to the user."""

    def __init__(self, code: str, message: str, status: int = 422):
        super().__init__(message)
        self.code, self.message, self.status = code, message, status


def ffmpeg_available(config: Optional[Config] = None) -> bool:
    location = config.ffmpeg_location if config and config.ffmpeg_location else None
    if location:
        return bool(shutil.which("ffmpeg", path=location) and shutil.which("ffprobe", path=location))
    return bool(shutil.which("ffmpeg") and shutil.which("ffprobe"))


# ---- error translation ---------------------------------------------------------------------------
_COMMON_RULES = [
    (("private video", "video is private", "private account", "is private"), "video_private", "This content is private.", 422),
    (("login required", "log in", "logged-in", "logged in", "requiring login", "sign in to view", "cookies"),
     "login_required", "This content needs a login to view, so it can't be downloaded.", 422),
    (("age-restricted", "confirm your age", "inappropriate for some users"), "age_restricted",
     "This content is age-restricted and cannot be processed.", 422),
    (("not available in your country", "blocked it in your country", "not made this video available", "geo-restrict"),
     "region_restricted", "This content is not available from the server's region.", 422),
    (("video unavailable", "has been removed", "no longer available", "does not exist", "terminated",
      "video not available", "post not found", "page isn't available", "unavailable"),
     "video_unavailable", "This content is unavailable, deleted, or the link has expired.", 404),
    (("members-only", "members only", "join this channel"), "members_only", "This content is for members only.", 422),
    (("live event", "is live", "premiere", "live stream"), "live_unsupported", "Live streams and premieres are not supported.", 422),
    (("requested format is not available", "requested format not available"), "quality_unavailable",
     "The selected quality is not available for this video.", 422),
    (("there is no video in this post", "no video formats found", "no video in this"), "no_video",
     "This post doesn't contain a downloadable video.", 422),
    (("unsupported url",), "unsupported_content", "This type of link isn't supported.", 422),
    (("timed out", "timeout"), "upstream_timeout", "The video source took too long to respond. Try again.", 504),
    (("http error 429", "too many requests", "rate-limit", "rate limit"), "source_rate_limited",
     "The video source is rate-limiting this server. Try again later.", 503),
    (("ffmpeg", "ffprobe", "postprocessing"), "processing_failed", "Media conversion failed.", 500),
]
_YOUTUBE_RULES = [
    (("sign in to confirm", "confirm you're not a bot", "confirm you’re not a bot"), "source_blocked",
     "YouTube is blocking requests from this server right now. Try again later.", 503),
]
_TIKTOK_RULES = [
    (("your ip address is blocked",), "source_blocked", "TikTok is blocking requests from this server right now. Try again later.", 503),
    (("unable to extract", "unexpected response", "js challenge", "aweme"), "extractor_failed",
     "TikTok extraction failed. TikTok may have changed something. Try again later or update the server's yt-dlp.", 502),
]
_INSTAGRAM_RULES = [
    (("empty media response",), "login_required",
     "Instagram didn't return this post without a login. It may be private or restricted, so it can't be downloaded.", 422),
]


def translate_error(exc: Exception, platform: str = YOUTUBE) -> MediaError:
    """Map yt-dlp error text to a stable, user-safe error. Raw messages are only logged."""
    text = str(exc).lower()
    platform_rules = {YOUTUBE: _YOUTUBE_RULES, TIKTOK: _TIKTOK_RULES, INSTAGRAM: _INSTAGRAM_RULES}.get(platform, [])
    for needles, code, message, status in [*platform_rules, *_COMMON_RULES]:
        if any(n in text for n in needles):
            return MediaError(code, message, status)
    label = PLATFORM_LABELS.get(platform, "the source")
    return MediaError("extraction_failed", f"Could not read this video from {label}. It may be unsupported or temporarily unavailable.", 502)


# ---- short link resolution (TikTok) ----------------------------------------------------------------
class _NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, *args, **kwargs):  # never follow automatically; we validate each hop
        return None


def resolve_short_url(url: str, timeout: int = 8, max_hops: int = 3) -> str:
    """Follow a TikTok short link hop by hop. Every hop must be HTTPS on a TikTok host (SSRF guard)."""
    opener = urllib.request.build_opener(_NoRedirect)
    current = url
    for _ in range(max_hops + 1):
        request = urllib.request.Request(current, headers={"User-Agent": "Mozilla/5.0 (compatible; StreamDrop)"})
        try:
            response = opener.open(request, timeout=timeout)
            response.close()
            return current  # no further redirect
        except urllib.error.HTTPError as exc:
            if exc.code not in (301, 302, 303, 307, 308):
                raise ValidationError("short_link_unresolvable", "That short link could not be opened.", 422)
            location = exc.headers.get("Location") if exc.headers else None
            if not location:
                raise ValidationError("short_link_unresolvable", "That short link could not be opened.", 422)
            nxt = urljoin(current, location)
            parts = urlsplit(nxt)
            if parts.scheme != "https" or (parts.hostname or "").lower() not in TIKTOK_HOSTS | {"vm.tiktok.com", "vt.tiktok.com"}:
                raise ValidationError("short_link_unresolvable", "That short link did not lead to a TikTok video.", 422)
            if (parts.hostname or "").lower() in TIKTOK_HOSTS and "/video/" in parts.path:
                return nxt
            current = nxt
        except (urllib.error.URLError, OSError):
            raise ValidationError("short_link_unresolvable", "Could not reach TikTok to open that short link.", 422)
    raise ValidationError("short_link_unresolvable", "That short link redirected too many times.", 422)


# ---- metadata --------------------------------------------------------------------------------------
class _YtdlpLogger:
    """Route yt-dlp's own output through our redacting logger instead of raw stderr."""

    def debug(self, msg): pass
    def info(self, msg): pass
    def warning(self, msg): log.debug("yt-dlp warning: %s", redact(msg))
    def error(self, msg): log.debug("yt-dlp error: %s", redact(msg))


def _base_opts(config: Config, platform: str = YOUTUBE) -> dict:
    opts = {
        "logger": _YtdlpLogger(),
        "quiet": True,
        "no_warnings": True,
        "noplaylist": True,
        "socket_timeout": config.socket_timeout_seconds,
        "retries": 3,
        "extractor_retries": 2,
        "color": "never",
    }
    # Operator-supplied cookies are used for YouTube only; they are never sent to other platforms.
    if platform == YOUTUBE and config.cookies_file and Path(config.cookies_file).is_file():
        opts["cookiefile"] = config.cookies_file
    if config.ffmpeg_location:
        opts["ffmpeg_location"] = config.ffmpeg_location
    return opts


def _format_duration(seconds: Optional[int]) -> Optional[str]:
    if not seconds:
        return None
    h, rem = divmod(int(seconds), 3600)
    m, s = divmod(rem, 60)
    return f"{h}:{m:02d}:{s:02d}" if h else f"{m}:{s:02d}"


def _safe_thumbnail(info: dict, platform: str = YOUTUBE) -> Optional[str]:
    thumb = info.get("thumbnail") or ""
    try:
        parts = urlsplit(thumb)
    except ValueError:
        parts = None
    host = (parts.hostname or "").lower() if parts else ""
    if parts and parts.scheme == "https" and any(host == s or host.endswith("." + s) for s in THUMB_SUFFIXES.get(platform, ())):
        return thumb
    if platform == YOUTUBE:
        return f"https://i.ytimg.com/vi/{info.get('id')}/hqdefault.jpg"
    return None  # unknown host: show a placeholder rather than trust an arbitrary URL


def _is_watermarked(fmt: dict) -> bool:
    """yt-dlp's TikTok extractor labels watermarked files in `format_note`."""
    return "watermark" in (fmt.get("format_note") or "")


def _height_labels(heights: set) -> list:
    return [f"{h}p" for h in sorted(heights)]


def _watermark_capability(platform: str, video_fmts: list, mp4_ok: bool) -> dict:
    """Report watermark-free availability. 'available' is only True when the source itself offers a
    video file that its extractor does NOT label as watermarked. This is a signal, not a guarantee."""
    if platform == TIKTOK:
        if not mp4_ok:
            return {"applies": True, "available": False, "qualities": [],
                    "reason": "No downloadable video was found, so there is nothing to choose between."}
        clean = [f for f in video_fmts if not _is_watermarked(f)]
        if clean:
            heights = {int(f["height"]) for f in clean if f.get("height")}
            return {"applies": True, "available": True, "reason": None,
                    "qualities": _height_labels(heights) if len(heights) > 1 else [],
                    "note": "Based on how TikTok's files are labelled. Check the result before relying on it."}
        return {"applies": True, "available": False, "qualities": [],
                "reason": "Every file TikTok offers for this video is labelled as watermarked, so a watermark-free "
                          "version is not available. You can download the original version instead."}
    if platform == INSTAGRAM:
        return {"applies": True, "available": False, "qualities": [],
                "reason": "Instagram does not provide a separate watermark-free file. The video is downloaded as "
                          "Instagram serves it, and overlays added by the creator cannot be removed."}
    return {"applies": False, "available": False, "qualities": [], "reason": None}


def build_metadata(info: dict, config: Config, ffmpeg_ok: Optional[bool] = None, platform: str = YOUTUBE) -> dict:
    """Shape raw yt-dlp info into the API response. Only genuine, verified fields are returned."""
    ffmpeg_ok = ffmpeg_available(config) if ffmpeg_ok is None else ffmpeg_ok
    formats = info.get("formats") or []
    has_audio = any(f.get("acodec") not in (None, "none") for f in formats)
    duration = info.get("duration")

    if platform == YOUTUBE:
        video_fmts = [f for f in formats if f.get("vcodec") not in (None, "none") and f.get("height")]
        heights = {f["height"] for f in video_fmts}
        qualities = [h for h in VIDEO_QUALITIES if h in heights]  # only the standard ladder
        has_video = bool(heights)
        quality_mode = "selectable"
    else:
        video_fmts = [f for f in formats if f.get("vcodec") != "none"]
        heights = {int(f["height"]) for f in video_fmts if f.get("height")}
        has_video = bool(video_fmts)
        # Only expose a quality choice when the source really offers several; otherwise "original".
        qualities = sorted(heights)[-6:] if len(heights) > 1 else []
        quality_mode = "selectable" if qualities else "original"

    reason = None
    if info.get("is_live") or info.get("live_status") in ("is_live", "is_upcoming"):
        reason = "Live streams and premieres are not supported."
    elif duration and duration > config.max_duration_seconds:
        reason = f"Videos longer than {config.max_duration_seconds // 60} minutes are not allowed on this server."
    elif not ffmpeg_ok:
        reason = "FFmpeg is not available on the server."

    mp4_ok = reason is None and has_video
    mp3_ok = reason is None and has_audio
    return {
        "platform": platform,
        "platform_label": PLATFORM_LABELS.get(platform, platform),
        "video_id": info.get("id"),
        "title": info.get("title") or "Untitled",
        "thumbnail": _safe_thumbnail(info, platform),
        "duration": duration,
        "duration_text": _format_duration(duration),
        "uploader": info.get("uploader") or info.get("channel") or info.get("creator"),
        "max_height": max(heights) if heights else None,
        "resolutions": qualities,
        "quality_mode": quality_mode,
        "formats": {
            "mp4": {
                "available": mp4_ok,
                "qualities": _height_labels(set(qualities)) + (["best"] if mp4_ok else []),
                "reason": None if mp4_ok else (reason or "No downloadable video stream was found."),
            },
            "mp3": {
                "available": mp3_ok,
                "bitrates": list(AUDIO_BITRATES),
                "reason": None if mp3_ok else (reason or "No audio stream was found."),
            },
        },
        "watermark_free": _watermark_capability(platform, video_fmts, mp4_ok),
        "notes": PLATFORM_NOTES.get(platform, []),
    }


def fetch_metadata(url: str, config: Config, platform: str = YOUTUBE) -> dict:
    """Extract metadata only (download=False). Raises MediaError."""
    opts = {**_base_opts(config, platform), "skip_download": True}
    try:
        with yt_dlp.YoutubeDL(opts) as ydl:
            info = ydl.extract_info(url, download=False)
    except (DownloadError, ExtractorError) as exc:
        log.warning("metadata extraction failed (%s): %s", platform, redact(exc))
        raise translate_error(exc, platform)
    except Exception:
        log.exception("unexpected metadata failure")
        raise MediaError("extraction_failed", "Could not read this video.", 502)
    if not info:
        raise MediaError("extraction_failed", "Could not read this video.", 502)
    if info.get("_type") == "playlist":
        raise MediaError("unsupported_content", "This link points to several items (a playlist or carousel). "
                         "Use a link to a single video.", 422)
    return build_metadata(info, config, platform=platform)


# ---- download --------------------------------------------------------------------------------------
def video_format_selector(quality, watermark_free: bool = False) -> str:
    """Exact-height selection: never silently substitute a different resolution.
    With watermark_free, files whose format_note says 'watermark' are excluded entirely."""
    wm = "[format_note!*=?watermark]" if watermark_free else ""
    if quality == "best":
        return f"bv*{wm}+ba/b{wm}"
    h = int(quality)
    return f"bv*[height={h}]{wm}+ba/b[height={h}]{wm}"


def build_download_opts(job_request, work_dir: str, config: Config, hooks: dict) -> dict:
    opts = {
        **_base_opts(config, getattr(job_request, "platform", YOUTUBE)),
        "outtmpl": str(Path(work_dir) / "media.%(ext)s"),  # unique per-job directory
        "overwrites": True,
        "max_filesize": config.max_filesize_mb * 1024 * 1024,
        "progress_hooks": [hooks["progress"]],
        "postprocessor_hooks": [hooks["postprocessor"]],
        "concurrent_fragment_downloads": 1,
    }
    if job_request.fmt == "mp3":
        opts.update(
            format="bestaudio/best",
            postprocessors=[{"key": "FFmpegExtractAudio", "preferredcodec": "mp3", "preferredquality": str(job_request.bitrate)}],
        )
    else:
        opts.update(
            format=video_format_selector(job_request.quality, getattr(job_request, "watermark_free", False)),
            format_sort=["res", "ext"],  # among equal resolutions prefer mp4/m4a
            merge_output_format="mp4",
            postprocessors=[{"key": "FFmpegVideoRemuxer", "preferedformat": "mp4"}],
        )
    return opts


def run_download(job, report: Callable[..., None], config: Config) -> dict:
    """Execute one job inside its private directory and return file details."""
    req = job.request
    if not ffmpeg_available(config):
        raise MediaError("ffmpeg_missing", "Media processing is unavailable: FFmpeg is not installed on the server.", 503)

    def on_progress(d: dict) -> None:
        if d.get("status") == "downloading":
            info = d.get("info_dict") or {}
            vcodec, acodec = info.get("vcodec"), info.get("acodec")
            stream = "video" if (vcodec not in (None, "none") and acodec in (None, "none")) else \
                     "audio" if (acodec not in (None, "none") and vcodec in (None, "none")) else "combined"
            total = d.get("total_bytes") or d.get("total_bytes_estimate")
            done = d.get("downloaded_bytes")
            percent = round(done / total * 100, 1) if total and done is not None else None
            if percent is None and d.get("fragment_count"):
                percent = round((d.get("fragment_index") or 0) / d["fragment_count"] * 100, 1)
            report("downloading", percent=percent, downloaded_bytes=done, total_bytes=total,
                   speed=d.get("speed"), eta=d.get("eta"), stream=stream,
                   indeterminate=percent is None)
        elif d.get("status") == "finished":
            report("finalizing", indeterminate=True)

    def on_postprocess(d: dict) -> None:
        if d.get("status") != "started":
            return
        name = d.get("postprocessor", "")
        if name == "FFmpegExtractAudio":
            report("converting", indeterminate=True)  # FFmpeg gives no reliable percentage
        elif name in ("Merger", "FFmpegMerger"):
            report("merging", indeterminate=True)
        else:
            report("finalizing", indeterminate=True)

    report("fetching", indeterminate=True)
    opts = build_download_opts(req, job.work_dir, config, {"progress": on_progress, "postprocessor": on_postprocess})
    try:
        with yt_dlp.YoutubeDL(opts) as ydl:
            info = ydl.extract_info(req.url, download=True)
    except (DownloadError, ExtractorError) as exc:
        log.warning("download failed (%s): %s", req.platform, redact(exc))
        raise translate_error(exc, req.platform)

    # Defence in depth: never deliver a file labelled as watermarked when watermark-free was requested.
    if getattr(req, "watermark_free", False):
        used = (info or {}).get("requested_formats") or [info or {}]
        if any(_is_watermarked(f) for f in used):
            raise MediaError("watermark_free_unavailable",
                             "A watermark-free version could not be obtained for this video.", 422)

    ext = "mp3" if req.fmt == "mp3" else "mp4"
    path = Path(job.work_dir) / f"media.{ext}"
    if not path.is_file() or path.stat().st_size == 0:
        raise MediaError("processing_failed", "The output file could not be created.", 500)
    size = path.stat().st_size
    if size > config.max_filesize_mb * 1024 * 1024:
        raise MediaError("file_too_large", f"The result exceeds the {config.max_filesize_mb} MB limit.", 422)

    suffix = f" [{req.quality}p]" if req.fmt == "mp4" and req.quality != "best" else \
             f" [{req.bitrate}kbps]" if req.fmt == "mp3" else ""
    filename = safe_filename((info or {}).get("title"), suffix, ext)
    job.title = (info or {}).get("title")
    return {"path": str(path), "filename": filename, "size": size,
            "mimetype": "audio/mpeg" if ext == "mp3" else "video/mp4"}
