// Client-side platform detection and friendly URL hints. These are conveniences only:
// the backend re-validates every URL and is the source of truth.

export const PLATFORMS = {
  youtube: { id: 'youtube', label: 'YouTube' },
  tiktok: { id: 'tiktok', label: 'TikTok' },
  instagram: { id: 'instagram', label: 'Instagram' },
};

const HOSTS = {
  youtube: ['youtube.com', 'm.youtube.com', 'music.youtube.com', 'youtu.be'],
  tiktok: ['tiktok.com', 'm.tiktok.com', 'vm.tiktok.com', 'vt.tiktok.com'],
  instagram: ['instagram.com'],
};

/** Add https:// when the user pasted a bare link such as "tiktok.com/@a/video/123". */
export function normalizeUrl(raw) {
  const value = String(raw || '').trim();
  if (!value) return '';
  return /^[a-z][a-z0-9+.-]*:/i.test(value) ? value : `https://${value}`;
}

function parse(raw) {
  try {
    const url = new URL(normalizeUrl(raw));
    return { host: url.hostname.toLowerCase().replace(/^www\./, ''), path: url.pathname, search: url.searchParams };
  } catch {
    return null;
  }
}

export function detectPlatform(raw) {
  const parsed = parse(raw);
  if (!parsed) return null;
  return Object.keys(HOSTS).find((id) => HOSTS[id].includes(parsed.host)) || null;
}

/** Returns a platform-specific message when the link is clearly not a single video, else null. */
export function urlHint(raw) {
  if (!String(raw || '').trim()) return null;
  const parsed = parse(raw);
  const platform = detectPlatform(raw);
  if (!parsed || !platform) return 'Only YouTube, TikTok and Instagram links are supported.';
  const { host, path, search } = parsed;
  if (platform === 'youtube') {
    const ok = host === 'youtu.be' ? /^\/[\w-]{11}/.test(path) : path === '/watch' ? search.has('v') : /^\/(shorts|embed|live|v)\/[\w-]{11}/.test(path);
    return ok ? null : 'Use a link to a single YouTube video (playlists and channels are not supported).';
  }
  if (platform === 'tiktok') {
    if (host.startsWith('vm.') || host.startsWith('vt.') || /^\/t\/[\w-]+/.test(path) || /^\/@[\w.]+\/video\/\d+/.test(path)) return null;
    if (/^\/@[\w.]+\/photo\//.test(path)) return 'TikTok photo posts are not supported. Use a link to a video.';
    if (/^\/@[\w.]+\/?$/.test(path)) return 'That looks like a TikTok profile. Use a link to a single video.';
    return 'Use a link to a single TikTok video (tiktok.com/@user/video/…).';
  }
  if (/^\/stories\//.test(path)) return 'Instagram Stories need a login and are not supported.';
  if (/^\/share\//.test(path)) return 'Share links are not supported. Open the Reel and copy its regular link.';
  if (/^\/([\w.]+\/)?(reel|reels|p|tv)\/[\w-]{5,}/.test(path)) return null;
  return 'Use a link to a single Instagram Reel or video post (instagram.com/reel/… or /p/…).';
}
