import DownloadForm from './DownloadForm.jsx';
import PlatformIcon from './PlatformIcon.jsx';

export default function Hero({ backend }) {
  return (
    <section id="home" className="hero">
      <div className="container hero__inner">
        <h1>Your Media. Your Format. Your Choice.</h1>
        <p className="hero__lead">
          Choose your format and available quality, then download your media in a few simple steps.
        </p>
        <ul className="hero__platforms" aria-label="Supported platforms">
          {['youtube', 'tiktok', 'instagram'].map((id) => (
            <li key={id} className={`platform-chip platform-chip--${id}`}>
              <PlatformIcon platform={id} size={16} /> {{ youtube: 'YouTube', tiktok: 'TikTok', instagram: 'Instagram' }[id]}
            </li>
          ))}
        </ul>
        <DownloadForm backend={backend} />
      </div>
    </section>
  );
}
