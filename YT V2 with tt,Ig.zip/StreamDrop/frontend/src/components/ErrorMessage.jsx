import { AlertTriangle, X } from 'lucide-react';

export default function ErrorMessage({ error, onRetry, retryLabel = 'Try again', onDismiss }) {
  if (!error) return null;
  return (
    <div className="error" role="alert">
      <AlertTriangle size={18} aria-hidden="true" />
      <p>{error.message}</p>
      <div className="error__actions">
        {onRetry && <button type="button" className="btn btn--small" onClick={onRetry}>{retryLabel}</button>}
        <button type="button" className="icon-btn" onClick={onDismiss} aria-label="Dismiss message"><X size={16} /></button>
      </div>
    </div>
  );
}
