// Simple outline glyphs (stroke = currentColor). Lucide's brand icons are deprecated, so these are local.
const PATHS = {
  youtube: (
    <>
      <rect x="2.5" y="5.5" width="19" height="13" rx="4" />
      <path d="M10 9.5v5l4.5-2.5z" fill="currentColor" stroke="none" />
    </>
  ),
  tiktok: (
    <>
      <path d="M14 4v10.2a3.7 3.7 0 1 1-3.7-3.7" />
      <path d="M14 4c.3 2.3 1.9 3.9 4.5 4.2" />
    </>
  ),
  instagram: (
    <>
      <rect x="3" y="3" width="18" height="18" rx="5" />
      <circle cx="12" cy="12" r="4" />
      <circle cx="17.2" cy="6.8" r="1" fill="currentColor" stroke="none" />
    </>
  ),
};

export default function PlatformIcon({ platform, size = 18 }) {
  if (!PATHS[platform]) return null;
  return (
    <svg className={`picon picon--${platform}`} width={size} height={size} viewBox="0 0 24 24" fill="none"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      {PATHS[platform]}
    </svg>
  );
}
