// Shown for TikTok and Instagram video downloads only. Enabled only when the backend verified that the
// source offers a file it does not label as watermarked.
export default function WatermarkOption({ platform, capability, checked, onChange, disabled }) {
  if (!capability?.applies) return null;
  const available = capability.available;
  return (
    <div className="check">
      <label className={`check__row${available ? '' : ' is-unavailable'}`}>
        <input type="checkbox" checked={available && checked} disabled={!available || disabled}
          onChange={(e) => onChange(e.target.checked)} aria-describedby="wm-help" />
        <span>Download without watermark (when available)</span>
      </label>
      <p id="wm-help" className={`hint hint--small${available ? '' : ' hint--warn'}`}>
        {available
          ? checked
            ? 'Only files the source does not label as watermarked will be used. If none matches your quality, the request is refused instead of falling back.'
            : platform === 'tiktok'
              ? 'Unchecked: you get the original version, which may include TikTok’s watermark.'
              : null
          : capability.reason}
      </p>
    </div>
  );
}
