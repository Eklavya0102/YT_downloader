const STATUS_TEXT = { checking: 'Checking server…', online: 'Server online', offline: 'Server unreachable' };

export default function Footer({ backendStatus, version }) {
  return (
    <footer className="footer">
      <div className="container footer__inner">
        <div>
          <p className="brand brand--footer">StreamDrop</p>
          <p className="footer__text">Download video and audio in your chosen format.</p>
          <p className={`status status--${backendStatus}`} role="status">
            <span className="status__dot" aria-hidden="true" /> {STATUS_TEXT[backendStatus]}{backendStatus === 'online' && version ? ` · v${version}` : ''}
          </p>
        </div>
        <nav aria-label="Footer" className="footer__nav">
          <a href="#home">Home</a><a href="#features">Features</a><a href="#how-it-works">How It Works</a><a href="#faq">FAQ</a>
        </nav>
        <div className="footer__notes">
          <p><strong>Privacy.</strong> StreamDrop has no accounts. Requested links are sent to the server to prepare your file, and server logs may include your IP address for rate limiting.</p>
          <p><strong>Responsible use.</strong> Download only content you own or have permission to use. You are responsible for complying with copyright law and platform terms.</p>
        </div>
      </div>
      <p className="container footer__copy">© {new Date().getFullYear()} StreamDrop. All rights reserved.</p>
    </footer>
  );
}
