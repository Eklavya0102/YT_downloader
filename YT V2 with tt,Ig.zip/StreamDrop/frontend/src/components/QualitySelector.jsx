export default function QualitySelector({ format, formatInfo, platform = 'youtube', quality, bitrate, maxHeight, watermarkFree, watermarkQualities = [], onQuality, onBitrate, disabled }) {
  if (format === 'mp3') {
    return (
      <fieldset className="field" disabled={disabled}>
        <legend>Audio quality</legend>
        <div className="chips" role="radiogroup" aria-label="Audio bitrate">
          {formatInfo.bitrates.map((b) => (
            <label key={b} className={`chip${bitrate === b ? ' is-active' : ''}`}>
              <input type="radio" name="bitrate" checked={bitrate === b} onChange={() => onBitrate(b)} /> {b} kbps
            </label>
          ))}
        </div>
        <p className="hint hint--small">Converting to MP3 can take a while and has no exact progress bar.</p>
      </fieldset>
    );
  }

  // Only qualities the source really offers. With watermark-free on, only qualities of the clean files.
  const real = (watermarkFree ? watermarkQualities : formatInfo.qualities).filter((q) => q !== 'best');
  if (real.length === 0) {
    return (
      <fieldset className="field">
        <legend>Video quality</legend>
        <p className="hint">Original quality. {platform === 'youtube' ? '' : 'This source offers a single quality, so there is nothing to choose.'}</p>
      </fieldset>
    );
  }
  const options = [...real, 'best'];
  return (
    <fieldset className="field" disabled={disabled}>
      <legend>Video quality</legend>
      <div className="chips" role="radiogroup" aria-label="Video quality">
        {options.map((q) => (
          <label key={q} className={`chip${quality === q ? ' is-active' : ''}`}>
            <input type="radio" name="quality" checked={quality === q} onChange={() => onQuality(q)} />
            {q === 'best' ? `Best available${platform === 'youtube' && maxHeight ? ` (${maxHeight}p)` : ''}` : q}
          </label>
        ))}
      </div>
      <p className="hint hint--small">
        {platform === 'youtube' ? 'Only resolutions found in this video are listed.' : 'Only qualities this post actually offers are listed.'}
      </p>
    </fieldset>
  );
}
