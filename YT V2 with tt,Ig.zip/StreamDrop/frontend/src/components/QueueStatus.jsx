import { Hourglass } from 'lucide-react';

export default function QueueStatus({ job, queue }) {
  return (
    <div className="queue" role="status">
      <Hourglass size={18} aria-hidden="true" />
      <div>
        <strong>
          {job.queue_position ? `Waiting in queue: position ${job.queue_position}` : 'Waiting to start'}
        </strong>
        {queue && <p className="hint hint--small">{queue.waiting} of {queue.max_waiting} waiting slots in use.</p>}
        <p className="hint hint--small">Beta service: if the server restarts, queued jobs are lost and you will need to start again.</p>
      </div>
    </div>
  );
}
