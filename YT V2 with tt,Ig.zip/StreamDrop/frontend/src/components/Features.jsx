import { Film, Globe, Layers, Music, ShieldCheck, Smartphone } from 'lucide-react';

const FEATURES = [
  { Icon: Layers, title: 'Multiple video resolutions', text: 'See which of 360p, 480p, 720p and 1080p the video really offers, plus the best available.' },
  { Icon: Film, title: 'MP4 video downloads', text: 'Audio and video streams are merged into a single MP4 file.' },
  { Icon: Music, title: 'MP3 audio extraction', text: 'Pull the audio track and convert it to MP3 at 128–320 kbps. Works across the supported platforms.' },
  { Icon: Globe, title: 'Simple browser-based downloads', text: 'No installs or accounts. The finished file saves through your browser.' },
  { Icon: Smartphone, title: 'Responsive interface', text: 'The same flow works on phones, tablets and desktops.' },
  { Icon: ShieldCheck, title: 'Secure input validation', text: 'Only single video links from YouTube, TikTok and Instagram are accepted, and every request is checked on the server.' },
];

export default function Features() {
  return (
    <section id="features" className="section">
      <div className="container">
        <h2 className="section__title">Features</h2>
        <ul className="grid">
          {FEATURES.map(({ Icon, title, text }) => (
            <li key={title} className="card feature">
              <span className="feature__icon"><Icon size={20} aria-hidden="true" /></span>
              <h3>{title}</h3>
              <p>{text}</p>
            </li>
          ))}
        </ul>
      </div>
    </section>
  );
}
