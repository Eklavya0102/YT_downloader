import { useState } from 'react';
import { Download, ExternalLink, Menu, X } from 'lucide-react';

const LINKS = [
  { href: '#home', label: 'Home' },
  { href: '#features', label: 'Features' },
  { href: '#how-it-works', label: 'How It Works' },
  { href: '#faq', label: 'FAQ' },
];
const GITHUB_URL = (import.meta.env.VITE_GITHUB_URL || '').trim();

export default function Navbar() {
  const [open, setOpen] = useState(false);
  return (
    <header className="navbar">
      <div className="container navbar__inner">
        <a href="#home" className="brand" aria-label="StreamDrop home">
          <span className="brand__mark"><Download size={18} aria-hidden="true" /></span>
          StreamDrop
        </a>
        <nav id="site-nav" className={`navbar__links${open ? ' is-open' : ''}`} aria-label="Main">
          {LINKS.map((l) => (
            <a key={l.href} href={l.href} onClick={() => setOpen(false)}>{l.label}</a>
          ))}
          {GITHUB_URL && (
            <a href={GITHUB_URL} target="_blank" rel="noopener noreferrer" className="navbar__ext">
              GitHub <ExternalLink size={14} aria-hidden="true" />
            </a>
          )}
        </nav>
        <button type="button" className="navbar__toggle" aria-expanded={open} aria-controls="site-nav"
          aria-label={open ? 'Close menu' : 'Open menu'} onClick={() => setOpen((o) => !o)}>
          {open ? <X size={22} /> : <Menu size={22} />}
        </button>
      </div>
    </header>
  );
}
