import { Film, Music } from 'lucide-react';

const OPTIONS = [
  { value: 'mp4', label: 'MP4 video', Icon: Film },
  { value: 'mp3', label: 'MP3 audio', Icon: Music },
];

export default function FormatSelector({ formats, value, onChange, disabled }) {
  return (
    <fieldset className="field" disabled={disabled}>
      <legend>Format</legend>
      <div className="segmented" role="radiogroup" aria-label="Format">
        {OPTIONS.map(({ value: v, label, Icon }) => {
          const available = formats[v]?.available;
          return (
            <label key={v} className={`segmented__item${value === v ? ' is-active' : ''}${available ? '' : ' is-unavailable'}`}>
              <input type="radio" name="format" value={v} checked={value === v} onChange={() => onChange(v)} />
              <Icon size={16} aria-hidden="true" /> {label}
              {!available && <span className="tag">unavailable</span>}
            </label>
          );
        })}
      </div>
    </fieldset>
  );
}
