const STEPS = [
  { title: 'Paste a supported video URL', text: 'Copy a YouTube video link and press Fetch Details.' },
  { title: 'Select format and available quality', text: 'Pick MP4 or MP3, then one of the qualities listed for that video.' },
  { title: 'Download the resulting file', text: 'Wait for processing to finish. The file is then sent to your browser.' },
];

export default function HowItWorks() {
  return (
    <section id="how-it-works" className="section section--alt">
      <div className="container">
        <h2 className="section__title">How It Works</h2>
        <ol className="steps">
          {STEPS.map((s) => (
            <li key={s.title} className="steps__item">
              <h3>{s.title}</h3>
              <p>{s.text}</p>
            </li>
          ))}
        </ol>
      </div>
    </section>
  );
}
