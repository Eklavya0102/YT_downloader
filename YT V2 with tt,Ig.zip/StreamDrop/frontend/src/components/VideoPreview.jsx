import { useState } from 'react';
import { Clock, User } from 'lucide-react';
import PlatformIcon from './PlatformIcon.jsx';

export default function VideoPreview({ metadata }) {
  const [imgFailed, setImgFailed] = useState(false);
  const platform = metadata.platform || 'youtube';
  const showImage = metadata.thumbnail && !imgFailed;
  return (
    <div className="preview">
      {showImage ? (
        <img src={metadata.thumbnail} alt="" className="preview__thumb" loading="lazy" referrerPolicy="no-referrer"
          width="320" height="180" onError={() => setImgFailed(true)} />
      ) : (
        <div className="preview__thumb preview__thumb--empty" aria-hidden="true"><PlatformIcon platform={platform} size={36} /></div>
      )}
      <div className="preview__text">
        <span className={`badge badge--${platform}`}><PlatformIcon platform={platform} size={14} /> {metadata.platform_label || 'YouTube'}</span>
        <h2 className="preview__title">{metadata.title}</h2>
        <p className="preview__meta">
          {metadata.duration_text && <span><Clock size={14} aria-hidden="true" /> {metadata.duration_text}</span>}
          {metadata.uploader && <span><User size={14} aria-hidden="true" /> {metadata.uploader}</span>}
        </p>
        <p className="preview__meta">
          {metadata.resolutions.length
            ? `Qualities found: ${metadata.resolutions.map((r) => `${r}p`).join(', ')}`
            : metadata.formats.mp4.available ? 'This source offers a single quality (original).' : 'No video stream found'}
        </p>
        {metadata.notes?.map((n) => <p key={n} className="hint hint--small">{n}</p>)}
      </div>
    </div>
  );
}
