const ITEMS = [
  ['Which links work?', 'Links to a single public video on YouTube (including Shorts), TikTok (including vm.tiktok.com short links) or Instagram (Reels and public video posts). Playlists, profiles, Stories, photo posts and other sites are rejected. Private or login-only posts cannot be downloaded, and support for TikTok and Instagram can break when those platforms change.'],
  ['What does “Download without watermark” do?', 'For TikTok, it is offered only when the source provides a file it does not label as watermarked. If not, you will see why and can choose the original version, which may carry TikTok’s watermark. Instagram does not provide a separate watermark-free file, so the option stays off. Never remove a creator’s attribution or pass work off as your own.'],
  ['Why am I waiting in a queue?', 'Media processing is limited so the service stays stable. Jobs run one at a time and a small number can wait. If the queue is full, try again shortly.'],
  ['Why is the first request slow?', 'The backend runs on free hosting that sleeps when idle. The first request after a pause can take up to a minute.'],
  ['How long are files kept?', 'Finished files are deleted automatically a few minutes after they are ready or delivered. Download promptly.'],
  ['Can I download any video?', 'No. Only download content you own or have permission to use, and follow copyright law and the platform’s terms. Some videos are private, restricted, live or too long and cannot be processed.'],
];

export default function Faq() {
  return (
    <section id="faq" className="section">
      <div className="container container--narrow">
        <h2 className="section__title">FAQ</h2>
        {ITEMS.map(([q, a]) => (
          <details key={q} className="faq">
            <summary>{q}</summary>
            <p>{a}</p>
          </details>
        ))}
      </div>
    </section>
  );
}
