import Navbar from './components/Navbar.jsx';
import Hero from './components/Hero.jsx';
import Features from './components/Features.jsx';
import HowItWorks from './components/HowItWorks.jsx';
import Faq from './components/Faq.jsx';
import Footer from './components/Footer.jsx';
import { useBackendStatus } from './hooks/useBackendStatus.js';

export default function App() {
  const backend = useBackendStatus();
  return (
    <>
      <a className="skip-link" href="#main">Skip to content</a>
      <Navbar />
      <main id="main">
        <Hero backend={backend} />
        <Features />
        <HowItWorks />
        <Faq />
      </main>
      <Footer backendStatus={backend.status} version={backend.version} />
    </>
  );
}
