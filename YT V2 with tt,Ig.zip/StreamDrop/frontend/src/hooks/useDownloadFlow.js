import { useCallback, useEffect, useRef, useState } from 'react';
import { ApiError, cancelDownload, createDownload, downloadFileUrl, fetchMetadata, getDownload } from '../services/api.js';
import { normalizeUrl, urlHint } from '../utils/platform.js';

const POLL_MS = 1500;
const MAX_POLL_FAILURES = 5;

const initial = {
  phase: 'idle', // idle | fetching | ready | submitting | tracking | done
  url: '', metadata: null, format: 'mp4', quality: 'best', bitrate: 192, watermarkFree: false,
  job: null, queue: null, error: null, slow: false,
};

function triggerBrowserDownload(jobId) {
  const a = document.createElement('a');
  a.href = downloadFileUrl(jobId);
  a.rel = 'noopener';
  a.download = '';
  document.body.appendChild(a);
  a.click();
  a.remove();
}

/** Which "try again" action makes sense for an error. */
function retryFor(code, status, fallback) {
  if (code === 'watermark_free_unavailable') return 'original'; // user decides to switch; we never switch silently
  if (code === 'queue_full' || status === 429) return 'download';
  return fallback;
}

export function useDownloadFlow() {
  const [state, setState] = useState(initial);
  const patch = useCallback((p) => setState((s) => ({ ...s, ...p })), []);
  const metaAbort = useRef(null);
  const pollTimer = useRef(null);
  const pollAbort = useRef(null);
  const alive = useRef(true);

  const stopPolling = useCallback(() => {
    clearTimeout(pollTimer.current);
    pollAbort.current?.abort();
  }, []);

  useEffect(() => {
    alive.current = true;
    return () => { alive.current = false; metaAbort.current?.abort(); stopPolling(); };
  }, [stopPolling]);

  const setUrl = (url) => patch({ url, error: null });

  const loadDetails = useCallback(async () => {
    const url = normalizeUrl(state.url);
    if (!url) return patch({ error: { message: 'Paste a YouTube, TikTok or Instagram link first.' } });
    const hint = urlHint(url);
    if (hint) return patch({ error: { message: hint } }); // quick feedback; the server re-validates anyway
    stopPolling();
    metaAbort.current?.abort();
    const controller = new AbortController();
    metaAbort.current = controller;
    patch({ phase: 'fetching', error: null, metadata: null, job: null, queue: null, slow: false, watermarkFree: false });
    try {
      const { metadata } = await fetchMetadata(url, { signal: controller.signal, onSlow: () => alive.current && patch({ slow: true }) });
      const format = metadata.formats.mp4.available ? 'mp4' : 'mp3';
      patch({ phase: 'ready', metadata, format, quality: 'best', bitrate: 192, watermarkFree: false, slow: false });
    } catch (err) {
      if (err.name === 'AbortError') return;
      patch({ phase: 'idle', slow: false, error: { message: err.message, code: err.code, retry: 'details' } });
    }
  }, [state.url, patch, stopPolling]);

  const poll = useCallback((jobId, failures = 0) => {
    pollTimer.current = setTimeout(async () => {
      const controller = new AbortController();
      pollAbort.current = controller;
      try {
        const { job, queue } = await getDownload(jobId, { signal: controller.signal });
        if (!alive.current) return;
        if (job.status === 'completed') {
          patch({ phase: 'done', job, queue });
          triggerBrowserDownload(job.id);
        } else if (job.status === 'failed') {
          patch({ phase: 'ready', job: null, queue, error: { message: job.error?.message || 'The download failed.', code: job.error?.code, retry: retryFor(job.error?.code, 0, 'download') } });
        } else if (job.status === 'expired') {
          patch({ phase: 'ready', job: null, error: { message: 'This download expired. Start it again to get a fresh file.', retry: 'download' } });
        } else {
          patch({ job, queue });
          poll(jobId, 0);
        }
      } catch (err) {
        if (err.name === 'AbortError' || !alive.current) return;
        if (err.status === 404) {
          patch({ phase: 'ready', job: null, error: { message: 'The server no longer has this job. It may have restarted or the job expired. Please start again.', retry: 'download' } });
        } else if (failures + 1 >= MAX_POLL_FAILURES) {
          patch({ phase: 'ready', job: null, error: { message: `Lost contact with the server. ${err.message}`, retry: 'download' } });
        } else {
          poll(jobId, failures + 1);
        }
      }
    }, POLL_MS);
  }, [patch]);

  /** overrides.watermarkFree === false is the user explicitly choosing the original version. */
  const startDownload = useCallback(async (overrides = {}) => {
    if (!state.metadata) return;
    const watermarkFree = overrides.watermarkFree ?? state.watermarkFree;
    patch({ phase: 'submitting', error: null, watermarkFree });
    const payload = { url: normalizeUrl(state.url), format: state.format };
    if (state.format === 'mp4') {
      payload.quality = state.quality;
      if (state.metadata.platform !== 'youtube') payload.watermark_free = watermarkFree;
    } else {
      payload.audio_bitrate = state.bitrate;
    }
    try {
      const { job, queue } = await createDownload(payload);
      patch({ phase: 'tracking', job, queue });
      poll(job.id);
    } catch (err) {
      patch({ phase: 'ready', error: { message: err.message, code: err.code, retry: retryFor(err.code, err.status, null) } });
    }
  }, [state.metadata, state.url, state.format, state.quality, state.bitrate, state.watermarkFree, patch, poll]);

  const cancel = useCallback(async () => {
    const jobId = state.job?.id;
    if (!jobId) return;
    try {
      await cancelDownload(jobId);
      stopPolling();
      patch({ phase: 'ready', job: null, queue: null });
    } catch (err) {
      patch({ error: { message: err instanceof ApiError ? err.message : 'Could not cancel.' } });
    }
  }, [state.job, patch, stopPolling]);

  const reset = useCallback(() => {
    stopPolling();
    metaAbort.current?.abort();
    setState(initial);
  }, [stopPolling]);

  return {
    state, setUrl, loadDetails, startDownload, cancel, reset,
    setFormat: (format) => patch({ format, error: null }),
    setQuality: (quality) => patch({ quality }),
    setBitrate: (bitrate) => patch({ bitrate }),
    // Changing the option changes which qualities exist, so go back to "best" visibly rather than guess.
    setWatermarkFree: (watermarkFree) => patch({ watermarkFree, quality: 'best', error: null }),
    dismissError: () => patch({ error: null }),
    saveAgain: () => state.job && triggerBrowserDownload(state.job.id),
  };
}
