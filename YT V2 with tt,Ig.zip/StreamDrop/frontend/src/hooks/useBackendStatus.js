import { useCallback, useEffect, useRef, useState } from 'react';
import { getCapabilities, getHealth } from '../services/api.js';

const RECHECK_MS = 90000;

/** Real health check against /api/health. Also loads /api/capabilities once the service is up. */
export function useBackendStatus() {
  const [status, setStatus] = useState('checking'); // checking | online | offline
  const [capabilities, setCapabilities] = useState(null);
  const [version, setVersion] = useState(null);
  const mounted = useRef(true);

  const check = useCallback(async () => {
    try {
      const health = await getHealth();
      if (!mounted.current) return;
      setStatus('online');
      setVersion(health.version);
      const caps = await getCapabilities().catch(() => null);
      if (mounted.current && caps) setCapabilities(caps);
    } catch {
      if (mounted.current) setStatus('offline');
    }
  }, []);

  useEffect(() => {
    mounted.current = true;
    check();
    const timer = setInterval(() => { if (document.visibilityState === 'visible') check(); }, RECHECK_MS);
    return () => { mounted.current = false; clearInterval(timer); };
  }, [check]);

  return { status, capabilities, version, recheck: check };
}
