// The ONLY place that talks to the backend. Components never build URLs or call fetch directly.

function normalizeBase(value) {
  // Strip trailing slashes and an accidental "/api" suffix so paths never become /api/api/...
  return String(value || '').trim().replace(/\/+$/, '').replace(/\/api$/i, '');
}

const configured = normalizeBase(import.meta.env.VITE_API_BASE_URL);
// A localhost fallback is only applied during `npm run dev`; production builds must set the variable.
export const API_BASE = configured || (import.meta.env.DEV ? 'http://127.0.0.1:5000' : '');

export const endpoints = {
  health: '/api/health',
  capabilities: '/api/capabilities',
  metadata: '/api/metadata',
  downloads: '/api/downloads',
  download: (id) => `/api/downloads/${encodeURIComponent(id)}`,
  file: (id) => `/api/downloads/${encodeURIComponent(id)}/file`,
};

export class ApiError extends Error {
  constructor(message, { status = 0, code = 'unknown', retryAfter = null } = {}) {
    super(message);
    this.name = 'ApiError';
    this.status = status;
    this.code = code;
    this.retryAfter = retryAfter;
  }
}

const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

function messageFor(status, serverMessage, retryAfter) {
  if (status === 429) {
    const wait = retryAfter ? ` Please wait about ${retryAfter} seconds and try again.` : ' Please wait a moment and try again.';
    return `Too many requests.${wait}`;
  }
  if (status === 503) return serverMessage || 'The service is busy or still starting up. Please try again shortly.';
  if (status === 500) return 'The server hit an unexpected error. Please try again.';
  if (status === 502 || status === 504) return serverMessage || 'The server could not reach the video source. Please try again.';
  return serverMessage || `Request failed (HTTP ${status}).`;
}

/**
 * request(path, options)
 *  - timeoutMs: abort after this long. Use longer values for a possibly sleeping backend.
 *  - retries: extra attempts for GET requests only (max 2), for network errors/timeouts/502/504.
 *  - onSlow: called once if the first attempt is still pending after slowAfterMs (cold-start hint).
 *  - signal: caller's AbortSignal for cancellation.
 */
async function request(path, { method = 'GET', body, signal, timeoutMs = 20000, retries = 0, onSlow, slowAfterMs = 5000 } = {}) {
  if (!API_BASE) {
    throw new ApiError('The app is not configured. Set VITE_API_BASE_URL to your backend URL and redeploy.', { code: 'not_configured' });
  }
  const attempts = method === 'GET' ? Math.min(retries, 2) + 1 : 1; // never retry non-idempotent calls
  let lastError;

  for (let attempt = 0; attempt < attempts; attempt += 1) {
    const controller = new AbortController();
    const onAbort = () => controller.abort();
    if (signal) {
      if (signal.aborted) throw new DOMException('Aborted', 'AbortError');
      signal.addEventListener('abort', onAbort, { once: true });
    }
    let timedOut = false;
    const timeout = setTimeout(() => { timedOut = true; controller.abort(); }, timeoutMs);
    const slowTimer = onSlow && attempt === 0 ? setTimeout(onSlow, slowAfterMs) : null;

    try {
      const response = await fetch(`${API_BASE}${path}`, {
        method,
        headers: body ? { 'Content-Type': 'application/json' } : undefined,
        body: body ? JSON.stringify(body) : undefined,
        signal: controller.signal,
        cache: 'no-store',
      });
      const text = await response.text();
      let data = null;
      try { data = text ? JSON.parse(text) : null; } catch { data = null; }

      if (!response.ok) {
        const retryAfter = Number(response.headers.get('Retry-After')) || null;
        const err = data?.error || {};
        const apiError = new ApiError(messageFor(response.status, err.message, retryAfter), {
          status: response.status, code: err.code || `http_${response.status}`, retryAfter,
        });
        if ([502, 504].includes(response.status) && attempt < attempts - 1) { lastError = apiError; await sleep(2000); continue; }
        throw apiError;
      }
      if (!data || data.ok !== true) {
        throw new ApiError('The server sent an unexpected response. Check that VITE_API_BASE_URL points to the StreamDrop backend.', { status: response.status, code: 'bad_response' });
      }
      return data; // only returned after the server confirmed success
    } catch (error) {
      if (error instanceof ApiError) throw error;
      if (error.name === 'AbortError' && !timedOut) throw error; // cancelled by the caller
      lastError = timedOut
        ? new ApiError('The server took too long to respond. Free hosting sleeps when idle and can need about a minute to wake up. Please try again.', { code: 'timeout' })
        : new ApiError('Cannot reach the server. Check your connection, and that the backend is running and allows this site (CORS).', { code: 'network' });
      if (attempt < attempts - 1) await sleep(2000);
    } finally {
      clearTimeout(timeout);
      if (slowTimer) clearTimeout(slowTimer);
      if (signal) signal.removeEventListener('abort', onAbort);
    }
  }
  throw lastError;
}

// A sleeping Render service can take about a minute to respond, so health/metadata allow a long wait.
export const getHealth = (opts = {}) => request(endpoints.health, { timeoutMs: 60000, retries: 1, ...opts });
export const getCapabilities = (opts = {}) => request(endpoints.capabilities, { timeoutMs: 20000, ...opts });
export const fetchMetadata = (url, opts = {}) =>
  request(endpoints.metadata, { method: 'POST', body: { url }, timeoutMs: 70000, ...opts });
export const createDownload = (payload, opts = {}) =>
  request(endpoints.downloads, { method: 'POST', body: payload, timeoutMs: 70000, ...opts });
export const getDownload = (id, opts = {}) => request(endpoints.download(id), { timeoutMs: 15000, retries: 1, ...opts });
export const cancelDownload = (id, opts = {}) => request(endpoints.download(id), { method: 'DELETE', ...opts });
export const downloadFileUrl = (id) => `${API_BASE}${endpoints.file(id)}`;
