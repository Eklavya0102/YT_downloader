const ITEMS = [
  ['Which links work?', 'Links to a single YouTube video (youtube.com, m.youtube.com, music.youtube.com, youtu.be, Shorts). Playlists, channels and other sites are rejected.'],
  ['Why am I waiting in a queue?', 'Media processing is limited so the service stays stable. Jobs run one at a time and a small number can wait. If the queue is full, try again shortly.'],
  ['Why is the first request slow?', 'The backend runs on free hosting that sleeps when idle. The first request after a pause can take up to a minute.'],
  ['How long are files kept?', 'Finished files are deleted automatically a few minutes after they are ready or delivered. Download promptly.'],
  ['Can I download any video?', 'No. Only download content you own or have permission to use, and follow copyright law and the platform’s terms. Some videos are private, restricted, live or too long and cannot be processed.'],
];

export default function Faq() {
  return (
    <section id="faq" className="section">
      <div className="container container--narrow">
        <h2 className="section__title">FAQ</h2>
        {ITEMS.map(([q, a]) => (
          <details key={q} className="faq">
            <summary>{q}</summary>
            <p>{a}</p>
          </details>
        ))}
      </div>
    </section>
  );
}
