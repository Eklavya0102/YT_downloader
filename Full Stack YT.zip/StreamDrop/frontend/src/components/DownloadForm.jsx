import { Link2, Loader2, Download, RotateCcw } from 'lucide-react';
import { useDownloadFlow } from '../hooks/useDownloadFlow.js';
import VideoPreview from './VideoPreview.jsx';
import FormatSelector from './FormatSelector.jsx';
import QualitySelector from './QualitySelector.jsx';
import DownloadProgress from './DownloadProgress.jsx';
import QueueStatus from './QueueStatus.jsx';
import ErrorMessage from './ErrorMessage.jsx';

export default function DownloadForm({ backend }) {
  const flow = useDownloadFlow();
  const { state } = flow;
  const { phase, metadata, job, queue, error } = state;
  const busy = phase === 'fetching' || phase === 'submitting';
  const tracking = phase === 'tracking' || phase === 'done';
  const fmt = metadata?.formats?.[state.format];
  const canDownload = phase === 'ready' && fmt?.available;
  const serverQueue = queue || backend.capabilities?.queue;

  const onSubmit = (e) => { e.preventDefault(); if (!busy && !tracking) flow.loadDetails(); };

  return (
    <div className="card dl-card">
      <form onSubmit={onSubmit} className="url-row" noValidate>
        <label htmlFor="video-url" className="sr-only">YouTube video URL</label>
        <div className="url-field">
          <Link2 size={18} aria-hidden="true" />
          <input id="video-url" type="url" inputMode="url" autoComplete="off" spellCheck="false"
            placeholder="Paste a YouTube link, e.g. https://www.youtube.com/watch?v=…"
            value={state.url} onChange={(e) => flow.setUrl(e.target.value)} disabled={busy || tracking} />
        </div>
        <button type="submit" className="btn btn--primary" disabled={busy || tracking || !state.url.trim()}>
          {phase === 'fetching' ? <><Loader2 size={18} className="spin" aria-hidden="true" /> Fetching…</> : 'Fetch Details'}
        </button>
      </form>

      {phase === 'fetching' && (
        <p className="hint" role="status">
          {state.slow ? 'The server is waking up after being idle. This can take up to a minute.' : 'Reading video details…'}
        </p>
      )}
      <ErrorMessage error={error} onRetry={error?.retry === 'details' ? flow.loadDetails : error?.retry === 'download' ? flow.startDownload : null} onDismiss={flow.dismissError} />

      {metadata && (
        <div className="dl-body">
          <VideoPreview metadata={metadata} />
          {!tracking && (
            <>
              <FormatSelector formats={metadata.formats} value={state.format} onChange={flow.setFormat} disabled={busy} />
              {fmt && !fmt.available && <p className="hint hint--warn" role="status">{fmt.reason}</p>}
              {fmt?.available && (
                <QualitySelector format={state.format} formatInfo={fmt} quality={state.quality} bitrate={state.bitrate}
                  maxHeight={metadata.max_height} onQuality={flow.setQuality} onBitrate={flow.setBitrate} disabled={busy} />
              )}
              <button type="button" className="btn btn--primary btn--wide" onClick={flow.startDownload} disabled={!canDownload || busy}>
                {phase === 'submitting' ? <><Loader2 size={18} className="spin" aria-hidden="true" /> Adding to queue…</> : <><Download size={18} aria-hidden="true" /> Download {state.format.toUpperCase()}</>}
              </button>
            </>
          )}
          {tracking && job && (
            <>
              <DownloadProgress job={job} done={phase === 'done'} onCancel={flow.cancel} onSaveAgain={flow.saveAgain} />
              {job.status === 'queued' && <QueueStatus job={job} queue={serverQueue} />}
              {phase === 'done' && (
                <button type="button" className="btn btn--ghost" onClick={flow.reset}><RotateCcw size={16} aria-hidden="true" /> Download another</button>
              )}
            </>
          )}
        </div>
      )}

      {!tracking && serverQueue && (
        <p className="hint hint--small">
          Server load: {serverQueue.active}/{serverQueue.max_active} processing · {serverQueue.waiting}/{serverQueue.max_waiting} waiting
        </p>
      )}
      <p className="notice">
        Only download content you own or have permission to use. You are responsible for following copyright law and the platform's terms of service.
      </p>
    </div>
  );
}
