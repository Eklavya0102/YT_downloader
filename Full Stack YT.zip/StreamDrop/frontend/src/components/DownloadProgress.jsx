import { CheckCircle2, Download, Loader2, X } from 'lucide-react';

const mb = (n) => (n ? `${(n / 1048576).toFixed(1)} MB` : null);
const eta = (s) => (s || s === 0 ? `${Math.floor(s / 60)}:${String(Math.round(s % 60)).padStart(2, '0')} left` : null);

export default function DownloadProgress({ job, done, onCancel, onSaveAgain }) {
  const p = job.progress || {};
  const determinate = typeof p.percent === 'number' && !p.indeterminate;
  const pct = done ? 100 : determinate ? Math.min(100, p.percent) : null;
  const details = [
    p.stream && p.stream !== 'combined' ? `${p.stream} stream` : null,
    mb(p.downloaded_bytes) && mb(p.total_bytes) ? `${mb(p.downloaded_bytes)} of ${mb(p.total_bytes)}` : null,
    p.speed ? `${(p.speed / 1048576).toFixed(1)} MB/s` : null,
    eta(p.eta),
  ].filter(Boolean);

  return (
    <div className="progress" aria-live="polite">
      <div className="progress__head">
        <span className="progress__stage">
          {done ? <CheckCircle2 size={18} aria-hidden="true" /> : <Loader2 size={18} className="spin" aria-hidden="true" />}
          {done ? 'Ready — your download should start automatically' : job.stage_label}
        </span>
        {pct !== null && <span className="progress__pct">{Math.round(pct)}%</span>}
      </div>
      <div className={`bar${pct === null ? ' bar--indeterminate' : ''}`} role="progressbar" aria-label={job.stage_label}
        aria-valuemin={0} aria-valuemax={100} aria-valuenow={pct === null ? undefined : Math.round(pct)}>
        <div className="bar__fill" style={pct === null ? undefined : { width: `${pct}%` }} />
      </div>
      {details.length > 0 && !done && <p className="hint hint--small">{details.join(' · ')}</p>}
      {done && (
        <div className="progress__actions">
          <button type="button" className="btn btn--primary" onClick={onSaveAgain}><Download size={16} aria-hidden="true" /> Save {job.filename || 'file'}</button>
          {job.size_bytes ? <span className="hint hint--small">{mb(job.size_bytes)}</span> : null}
        </div>
      )}
      {!done && job.status === 'queued' && (
        <button type="button" className="btn btn--ghost" onClick={onCancel}><X size={16} aria-hidden="true" /> Cancel</button>
      )}
      {!done && job.status === 'processing' && <p className="hint hint--small">Processing has started and can no longer be cancelled.</p>}
    </div>
  );
}
