export default function QualitySelector({ format, formatInfo, quality, bitrate, maxHeight, onQuality, onBitrate, disabled }) {
  if (format === 'mp3') {
    return (
      <fieldset className="field" disabled={disabled}>
        <legend>Audio quality</legend>
        <div className="chips" role="radiogroup" aria-label="Audio bitrate">
          {formatInfo.bitrates.map((b) => (
            <label key={b} className={`chip${bitrate === b ? ' is-active' : ''}`}>
              <input type="radio" name="bitrate" checked={bitrate === b} onChange={() => onBitrate(b)} /> {b} kbps
            </label>
          ))}
        </div>
        <p className="hint hint--small">Converting to MP3 can take a while and has no exact progress bar.</p>
      </fieldset>
    );
  }
  return (
    <fieldset className="field" disabled={disabled}>
      <legend>Video quality</legend>
      <div className="chips" role="radiogroup" aria-label="Video quality">
        {formatInfo.qualities.map((q) => (
          <label key={q} className={`chip${quality === q ? ' is-active' : ''}`}>
            <input type="radio" name="quality" checked={quality === q} onChange={() => onQuality(q)} />
            {q === 'best' ? `Best available${maxHeight ? ` (${maxHeight}p)` : ''}` : q}
          </label>
        ))}
      </div>
      <p className="hint hint--small">Only resolutions found in this video are listed.</p>
    </fieldset>
  );
}
