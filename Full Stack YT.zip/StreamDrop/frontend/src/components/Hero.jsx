import DownloadForm from './DownloadForm.jsx';

export default function Hero({ backend }) {
  return (
    <section id="home" className="hero">
      <div className="container hero__inner">
        <h1>Your Media. Your Format. Your Choice.</h1>
        <p className="hero__lead">
          Choose your format and available quality, then download your media in a few simple steps.
        </p>
        <DownloadForm backend={backend} />
      </div>
    </section>
  );
}
