import { Clock, User } from 'lucide-react';

export default function VideoPreview({ metadata }) {
  return (
    <div className="preview">
      <img src={metadata.thumbnail} alt="" className="preview__thumb" loading="lazy" referrerPolicy="no-referrer" width="320" height="180" />
      <div className="preview__text">
        <h2 className="preview__title">{metadata.title}</h2>
        <p className="preview__meta">
          {metadata.duration_text && <span><Clock size={14} aria-hidden="true" /> {metadata.duration_text}</span>}
          {metadata.uploader && <span><User size={14} aria-hidden="true" /> {metadata.uploader}</span>}
        </p>
        <p className="preview__meta">
          {metadata.resolutions.length
            ? `Resolutions found: ${metadata.resolutions.map((r) => `${r}p`).join(', ')}${metadata.max_height ? ` (up to ${metadata.max_height}p)` : ''}`
            : 'No standard video resolutions found'}
        </p>
      </div>
    </div>
  );
}
