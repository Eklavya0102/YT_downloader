"""Input validation. The backend never trusts IDs, URLs or metadata sent by the browser."""
from __future__ import annotations

import re
import unicodedata
from dataclasses import dataclass
from typing import Union
from urllib.parse import parse_qs, urlsplit

from config import AUDIO_BITRATES, VIDEO_QUALITIES

# Exact-match allowlist. IP literals, localhost, and look-alike hosts can never match.
ALLOWED_HOSTS = frozenset(
    {"youtube.com", "www.youtube.com", "m.youtube.com", "music.youtube.com", "youtu.be"}
)
VIDEO_ID_RE = re.compile(r"^[A-Za-z0-9_-]{11}$")
JOB_ID_RE = re.compile(r"^[A-Za-z0-9_-]{20,64}$")
PATH_ID_PREFIXES = ("shorts", "embed", "live", "v")
FORMATS = ("mp4", "mp3")
MAX_URL_LENGTH = 2048


class ValidationError(Exception):
    """Raised for invalid client input. Carries a stable machine code and a safe message."""

    def __init__(self, code: str, message: str, status: int = 400):
        super().__init__(message)
        self.code = code
        self.message = message
        self.status = status


@dataclass(frozen=True)
class DownloadRequest:
    url: str
    video_id: str
    fmt: str
    quality: Union[int, str]  # height in pixels, or "best" (ignored for mp3)
    bitrate: int

    @property
    def fingerprint(self) -> str:
        return f"{self.video_id}:{self.fmt}:{self.quality}:{self.bitrate}"


def canonical_url(video_id: str) -> str:
    return f"https://www.youtube.com/watch?v={video_id}"


def parse_youtube_url(raw: object) -> tuple[str, str]:
    """Return (video_id, canonical_url) or raise ValidationError."""
    if not isinstance(raw, str):
        raise ValidationError("invalid_url", "A URL string is required.")
    url = raw.strip()
    if not url or len(url) > MAX_URL_LENGTH:
        raise ValidationError("invalid_url", "Enter a valid YouTube URL.")
    if any(ord(ch) < 33 or ord(ch) == 127 for ch in url):
        raise ValidationError("invalid_url", "The URL contains invalid characters.")
    try:
        parts = urlsplit(url)
        port = parts.port
    except ValueError:
        raise ValidationError("invalid_url", "Enter a valid YouTube URL.")
    if parts.scheme not in ("http", "https"):
        raise ValidationError("invalid_url", "Only http(s) YouTube links are supported.")
    if parts.username or parts.password:
        raise ValidationError("invalid_url", "URLs with credentials are not allowed.")
    if port not in (None, 80, 443):
        raise ValidationError("invalid_url", "Unexpected port in URL.")
    host = (parts.hostname or "").lower()
    if host not in ALLOWED_HOSTS:
        raise ValidationError("unsupported_host", "Only YouTube links are supported.")

    video_id = None
    segments = [s for s in parts.path.split("/") if s]
    if host == "youtu.be":
        if len(segments) == 1:
            video_id = segments[0]
    elif segments == ["watch"]:
        values = parse_qs(parts.query).get("v", [])
        if len(values) == 1:
            video_id = values[0]
    elif len(segments) == 2 and segments[0] in PATH_ID_PREFIXES:
        video_id = segments[1]

    if not video_id or not VIDEO_ID_RE.fullmatch(video_id):
        raise ValidationError(
            "unsupported_url", "Use a link to a single YouTube video (playlists and channels are not supported)."
        )
    return video_id, canonical_url(video_id)


def parse_format(raw: object) -> str:
    fmt = raw.strip().lower() if isinstance(raw, str) else ""
    if fmt not in FORMATS:
        raise ValidationError("invalid_format", f"Format must be one of: {', '.join(FORMATS)}.")
    return fmt


def parse_quality(raw: object) -> Union[int, str]:
    if raw is None:
        return "best"
    value = str(raw).strip().lower()
    if value == "best":
        return "best"
    match = re.fullmatch(r"(\d{3,4})p?", value)
    if not match or int(match.group(1)) not in VIDEO_QUALITIES:
        allowed = ", ".join(f"{q}p" for q in VIDEO_QUALITIES)
        raise ValidationError("invalid_quality", f"Quality must be one of: {allowed}, best.")
    return int(match.group(1))


def parse_bitrate(raw: object, default: int) -> int:
    if raw is None or raw == "":
        return default
    try:
        value = int(str(raw).lower().replace("kbps", "").strip())
    except ValueError:
        raise ValidationError("invalid_bitrate", "Invalid audio bitrate.")
    if value not in AUDIO_BITRATES:
        raise ValidationError(
            "invalid_bitrate", f"Audio bitrate must be one of: {', '.join(map(str, AUDIO_BITRATES))} kbps."
        )
    return value


def parse_download_request(data: object, default_bitrate: int) -> DownloadRequest:
    if not isinstance(data, dict):
        raise ValidationError("invalid_body", "Request body must be a JSON object.")
    video_id, url = parse_youtube_url(data.get("url"))
    fmt = parse_format(data.get("format"))
    quality = parse_quality(data.get("quality")) if fmt == "mp4" else "best"
    bitrate = parse_bitrate(data.get("audio_bitrate"), default_bitrate) if fmt == "mp3" else default_bitrate
    return DownloadRequest(url=url, video_id=video_id, fmt=fmt, quality=quality, bitrate=bitrate)


def safe_filename(title: object, suffix: str, ext: str) -> str:
    """Build a download filename from untrusted metadata: no separators, controls or leading dots."""
    text = unicodedata.normalize("NFKC", str(title or ""))
    text = re.sub(r"[^\w\-. ()\[\]]+", "", text, flags=re.UNICODE)
    text = re.sub(r"\s+", " ", text).strip(" ._-")[:100].strip(" ._-")
    base = text or "streamdrop"
    return f"{base}{suffix}.{ext}"
