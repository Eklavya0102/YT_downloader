"""yt-dlp integration: metadata extraction and media processing. No shell, no user-supplied args."""
from __future__ import annotations

import logging
import shutil
from pathlib import Path
from typing import Callable, Optional

import yt_dlp
from yt_dlp.utils import DownloadError, ExtractorError

from config import VIDEO_QUALITIES, AUDIO_BITRATES, Config
from validators import safe_filename

log = logging.getLogger("streamdrop.downloader")

ALLOWED_THUMB_HOSTS = ("ytimg.com", "ggpht.com")


class MediaError(Exception):
    """A failure that is safe to show to the user."""

    def __init__(self, code: str, message: str, status: int = 422):
        super().__init__(message)
        self.code, self.message, self.status = code, message, status


def ffmpeg_available(config: Optional[Config] = None) -> bool:
    location = config.ffmpeg_location if config and config.ffmpeg_location else None
    if location:
        return any(shutil.which(tool, path=location) for tool in ("ffmpeg",)) and bool(shutil.which("ffprobe", path=location))
    return bool(shutil.which("ffmpeg") and shutil.which("ffprobe"))


def translate_error(exc: Exception) -> MediaError:
    """Map yt-dlp error text to a stable, user-safe error. Raw messages are only logged."""
    text = str(exc).lower()
    rules = [
        (("private video",), "video_private", "This video is private.", 422),
        (("sign in to confirm", "confirm you're not a bot", "confirm you’re not a bot"), "source_blocked",
         "YouTube is blocking requests from this server right now. Try again later.", 503),
        (("age-restricted", "confirm your age", "inappropriate for some users"), "age_restricted",
         "This video is age-restricted and cannot be processed.", 422),
        (("not available in your country", "blocked it in your country", "geo", "not made this video available"),
         "region_restricted", "This video is not available from the server's region.", 422),
        (("video unavailable", "has been removed", "no longer available", "does not exist", "terminated"),
         "video_unavailable", "This video is unavailable or has been removed.", 404),
        (("members-only", "members only", "join this channel"), "members_only", "This video is for channel members only.", 422),
        (("live event", "is live", "premiere"), "live_unsupported", "Live streams and premieres are not supported.", 422),
        (("requested format is not available", "requested format not available"), "quality_unavailable",
         "The selected quality is not available for this video.", 422),
        (("timed out", "timeout"), "upstream_timeout", "The video source took too long to respond. Try again.", 504),
        (("http error 429", "too many requests"), "source_rate_limited", "The video source is rate-limiting this server. Try again later.", 503),
        (("ffmpeg", "ffprobe", "postprocessing"), "processing_failed", "Media conversion failed.", 500),
    ]
    for needles, code, message, status in rules:
        if any(n in text for n in needles):
            return MediaError(code, message, status)
    return MediaError("extraction_failed", "Could not read this video. It may be unsupported or temporarily unavailable.", 502)


def _base_opts(config: Config) -> dict:
    opts = {
        "quiet": True,
        "no_warnings": True,
        "noplaylist": True,
        "socket_timeout": config.socket_timeout_seconds,
        "retries": 3,
        "extractor_retries": 2,
        "color": "never",
    }
    if config.cookies_file and Path(config.cookies_file).is_file():
        opts["cookiefile"] = config.cookies_file
    if config.ffmpeg_location:
        opts["ffmpeg_location"] = config.ffmpeg_location
    return opts


def _format_duration(seconds: Optional[int]) -> Optional[str]:
    if not seconds:
        return None
    h, rem = divmod(int(seconds), 3600)
    m, s = divmod(rem, 60)
    return f"{h}:{m:02d}:{s:02d}" if h else f"{m}:{s:02d}"


def _safe_thumbnail(info: dict) -> str:
    thumb = info.get("thumbnail") or ""
    if thumb.startswith("https://") and any(f".{h}/" in thumb or thumb.split("/")[2].endswith(h) for h in ALLOWED_THUMB_HOSTS):
        return thumb
    return f"https://i.ytimg.com/vi/{info.get('id')}/hqdefault.jpg"


def build_metadata(info: dict, config: Config, ffmpeg_ok: Optional[bool] = None) -> dict:
    """Shape raw yt-dlp info into the API response. Only genuine, verified fields are returned."""
    ffmpeg_ok = ffmpeg_available(config) if ffmpeg_ok is None else ffmpeg_ok
    formats = info.get("formats") or []
    heights = {f["height"] for f in formats if f.get("vcodec") not in (None, "none") and f.get("height")}
    has_audio = any(f.get("acodec") not in (None, "none") for f in formats)
    qualities = [h for h in VIDEO_QUALITIES if h in heights]
    max_height = max(heights) if heights else None
    duration = info.get("duration")

    reason = None
    if info.get("is_live") or info.get("live_status") in ("is_live", "is_upcoming"):
        reason = "Live streams and premieres are not supported."
    elif duration and duration > config.max_duration_seconds:
        reason = f"Videos longer than {config.max_duration_seconds // 60} minutes are not allowed on this server."
    elif not ffmpeg_ok:
        reason = "FFmpeg is not available on the server."

    mp4_ok = reason is None and bool(heights)
    mp3_ok = reason is None and has_audio
    return {
        "video_id": info.get("id"),
        "title": info.get("title") or "Untitled",
        "thumbnail": _safe_thumbnail(info),
        "duration": duration,
        "duration_text": _format_duration(duration),
        "uploader": info.get("uploader") or info.get("channel"),
        "max_height": max_height,
        "resolutions": qualities,
        "formats": {
            "mp4": {
                "available": mp4_ok,
                "qualities": [f"{h}p" for h in qualities] + (["best"] if mp4_ok else []),
                "reason": None if mp4_ok else (reason or "No downloadable video stream was found."),
            },
            "mp3": {
                "available": mp3_ok,
                "bitrates": list(AUDIO_BITRATES),
                "reason": None if mp3_ok else (reason or "No audio stream was found."),
            },
        },
    }


def fetch_metadata(url: str, config: Config) -> dict:
    """Extract metadata only (download=False). Raises MediaError."""
    opts = {**_base_opts(config), "skip_download": True}
    try:
        with yt_dlp.YoutubeDL(opts) as ydl:
            info = ydl.extract_info(url, download=False)
    except (DownloadError, ExtractorError) as exc:
        log.warning("metadata extraction failed: %s", str(exc)[:300])
        raise translate_error(exc)
    except Exception:
        log.exception("unexpected metadata failure")
        raise MediaError("extraction_failed", "Could not read this video.", 502)
    if not info or info.get("_type") == "playlist":
        raise MediaError("unsupported_url", "Use a link to a single YouTube video.", 422)
    return build_metadata(info, config)


def video_format_selector(quality) -> str:
    """Exact-height selection: never silently substitute a different resolution."""
    if quality == "best":
        return "bv*+ba/b"
    return f"bv*[height={int(quality)}]+ba/b[height={int(quality)}]"


def build_download_opts(job_request, work_dir: str, config: Config, hooks: dict) -> dict:
    opts = {
        **_base_opts(config),
        "outtmpl": str(Path(work_dir) / "media.%(ext)s"),  # unique per-job directory
        "overwrites": True,
        "max_filesize": config.max_filesize_mb * 1024 * 1024,
        "progress_hooks": [hooks["progress"]],
        "postprocessor_hooks": [hooks["postprocessor"]],
        "concurrent_fragment_downloads": 1,
    }
    if job_request.fmt == "mp3":
        opts.update(
            format="bestaudio/best",
            postprocessors=[{"key": "FFmpegExtractAudio", "preferredcodec": "mp3", "preferredquality": str(job_request.bitrate)}],
        )
    else:
        opts.update(
            format=video_format_selector(job_request.quality),
            format_sort=["res", "ext"],  # among equal resolutions prefer mp4/m4a
            merge_output_format="mp4",
            postprocessors=[{"key": "FFmpegVideoRemuxer", "preferedformat": "mp4"}],
        )
    return opts


def run_download(job, report: Callable[..., None], config: Config) -> dict:
    """Execute one job inside its private directory and return file details."""
    req = job.request
    if not ffmpeg_available(config):
        raise MediaError("ffmpeg_missing", "Media processing is unavailable: FFmpeg is not installed on the server.", 503)

    def on_progress(d: dict) -> None:
        if d.get("status") == "downloading":
            info = d.get("info_dict") or {}
            vcodec, acodec = info.get("vcodec"), info.get("acodec")
            stream = "video" if (vcodec not in (None, "none") and acodec in (None, "none")) else \
                     "audio" if (acodec not in (None, "none") and vcodec in (None, "none")) else "combined"
            total = d.get("total_bytes") or d.get("total_bytes_estimate")
            done = d.get("downloaded_bytes")
            percent = round(done / total * 100, 1) if total and done is not None else None
            if percent is None and d.get("fragment_count"):
                percent = round((d.get("fragment_index") or 0) / d["fragment_count"] * 100, 1)
            report("downloading", percent=percent, downloaded_bytes=done, total_bytes=total,
                   speed=d.get("speed"), eta=d.get("eta"), stream=stream,
                   indeterminate=percent is None)
        elif d.get("status") == "finished":
            report("finalizing", indeterminate=True)

    def on_postprocess(d: dict) -> None:
        if d.get("status") != "started":
            return
        name = d.get("postprocessor", "")
        if name == "FFmpegExtractAudio":
            report("converting", indeterminate=True)  # FFmpeg gives no reliable percentage
        elif name in ("Merger", "FFmpegMerger"):
            report("merging", indeterminate=True)
        else:
            report("finalizing", indeterminate=True)

    report("fetching", indeterminate=True)
    opts = build_download_opts(req, job.work_dir, config, {"progress": on_progress, "postprocessor": on_postprocess})
    try:
        with yt_dlp.YoutubeDL(opts) as ydl:
            info = ydl.extract_info(req.url, download=True)
    except (DownloadError, ExtractorError) as exc:
        log.warning("download failed: %s", str(exc)[:300])
        raise translate_error(exc)

    ext = "mp3" if req.fmt == "mp3" else "mp4"
    path = Path(job.work_dir) / f"media.{ext}"
    if not path.is_file() or path.stat().st_size == 0:
        raise MediaError("processing_failed", "The output file could not be created.", 500)
    size = path.stat().st_size
    if size > config.max_filesize_mb * 1024 * 1024:
        raise MediaError("file_too_large", f"The result exceeds the {config.max_filesize_mb} MB limit.", 422)

    suffix = f" [{req.quality}p]" if req.fmt == "mp4" and req.quality != "best" else \
             f" [{req.bitrate}kbps]" if req.fmt == "mp3" else ""
    filename = safe_filename((info or {}).get("title"), suffix, ext)
    job.title = (info or {}).get("title")
    return {"path": str(path), "filename": filename, "size": size,
            "mimetype": "audio/mpeg" if ext == "mp3" else "video/mp4"}
