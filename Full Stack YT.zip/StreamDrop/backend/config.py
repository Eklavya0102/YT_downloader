"""Environment-driven configuration. All limits are tunable without code changes."""
from __future__ import annotations

import os
import re
import tempfile
from pathlib import Path
from dataclasses import dataclass
from typing import Tuple

APP_VERSION = "1.0.0"
AUDIO_BITRATES = (128, 192, 256, 320)
VIDEO_QUALITIES = (360, 480, 720, 1080)


def _load_env_file(path: Path) -> None:
    """Minimal .env reader for local development (no extra dependency). Real env vars win."""
    if not path.is_file():
        return
    for line in path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, _, value = line.partition("=")
        os.environ.setdefault(key.strip(), value.strip().strip("'\""))


def _int(name: str, default: int, minimum: int = 0) -> int:
    raw = os.environ.get(name, "").strip()
    try:
        value = int(raw) if raw else default
    except ValueError:
        value = default
    return max(minimum, value)


def _rate(name: str, default: str) -> Tuple[int, int]:
    raw = os.environ.get(name, "").strip() or default
    match = re.fullmatch(r"(\d+)/(\d+)", raw)
    if not match:
        match = re.fullmatch(r"(\d+)/(\d+)", default)
    limit, window = int(match.group(1)), int(match.group(2))
    return max(1, limit), max(1, window)


def _origins(raw: str) -> Tuple[str, ...]:
    out = []
    for item in raw.split(","):
        item = item.strip().rstrip("/")
        # A wildcard would make the CORS policy meaningless; refuse it.
        if item and item != "*":
            out.append(item)
    return tuple(out)


@dataclass(frozen=True)
class Config:
    app_env: str = "production"
    allowed_origins: Tuple[str, ...] = ()
    allowed_origin_regex: str = ""
    max_active_jobs: int = 1
    max_waiting_jobs: int = 5
    max_jobs_per_client: int = 2
    rate_metadata: Tuple[int, int] = (20, 60)
    rate_downloads: Tuple[int, int] = (5, 60)
    rate_status: Tuple[int, int] = (240, 60)
    job_ttl_seconds: int = 900
    delivered_grace_seconds: int = 300
    record_retention_seconds: int = 3600
    cleanup_interval_seconds: int = 60
    temp_dir: str = ""
    max_duration_seconds: int = 3600
    max_filesize_mb: int = 300
    default_audio_bitrate: int = 192
    metadata_timeout_seconds: int = 25
    socket_timeout_seconds: int = 15
    metadata_cache_seconds: int = 300
    trust_proxy_hops: int = 0
    log_level: str = "INFO"
    cookies_file: str = ""
    ffmpeg_location: str = ""
    version: str = APP_VERSION

    @classmethod
    def from_env(cls) -> "Config":
        _load_env_file(Path(__file__).resolve().parent / ".env")
        env = os.environ.get("APP_ENV", "production").strip().lower()
        default_origins = "http://localhost:5173,http://127.0.0.1:5173" if env == "development" else ""
        temp_dir = os.environ.get("TEMP_DIR", "").strip() or os.path.join(tempfile.gettempdir(), "streamdrop")
        bitrate = _int("DEFAULT_AUDIO_BITRATE", 192)
        return cls(
            app_env=env,
            allowed_origins=_origins(os.environ.get("ALLOWED_ORIGINS", default_origins)),
            allowed_origin_regex=os.environ.get("ALLOWED_ORIGIN_REGEX", "").strip(),
            max_active_jobs=_int("MAX_ACTIVE_JOBS", 1, 1),
            max_waiting_jobs=_int("MAX_WAITING_JOBS", 5, 0),
            max_jobs_per_client=_int("MAX_JOBS_PER_CLIENT", 2, 1),
            rate_metadata=_rate("RATE_LIMIT_METADATA", "20/60"),
            rate_downloads=_rate("RATE_LIMIT_DOWNLOADS", "5/60"),
            rate_status=_rate("RATE_LIMIT_STATUS", "240/60"),
            job_ttl_seconds=_int("JOB_TTL_SECONDS", 900, 30),
            delivered_grace_seconds=_int("DELIVERED_GRACE_SECONDS", 300, 5),
            record_retention_seconds=_int("RECORD_RETENTION_SECONDS", 3600, 60),
            cleanup_interval_seconds=_int("CLEANUP_INTERVAL_SECONDS", 60, 5),
            temp_dir=temp_dir,
            max_duration_seconds=_int("MAX_DURATION_SECONDS", 3600, 30),
            max_filesize_mb=_int("MAX_FILESIZE_MB", 300, 10),
            default_audio_bitrate=bitrate if bitrate in AUDIO_BITRATES else 192,
            metadata_timeout_seconds=_int("METADATA_TIMEOUT_SECONDS", 25, 5),
            socket_timeout_seconds=_int("SOCKET_TIMEOUT_SECONDS", 15, 5),
            metadata_cache_seconds=_int("METADATA_CACHE_SECONDS", 300, 0),
            trust_proxy_hops=_int("TRUST_PROXY_HOPS", 0, 0),
            log_level=os.environ.get("LOG_LEVEL", "INFO").strip().upper() or "INFO",
            cookies_file=os.environ.get("YTDLP_COOKIES_FILE", "").strip(),
            ffmpeg_location=os.environ.get("FFMPEG_LOCATION", "").strip(),
        )
